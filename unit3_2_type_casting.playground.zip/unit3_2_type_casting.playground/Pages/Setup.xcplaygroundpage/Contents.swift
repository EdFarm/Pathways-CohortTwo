//: ## Setup
/*:
 - callout(Setting this up):
 A continuation of our recipe app example...
 */
class Recipe {
    var name: String
    var ingredients: [String]
    var directions: [String]
    var cookingTime: Int

    init(name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.name = name
        self.ingredients = ingredients
        self.directions = directions
        self.cookingTime = cookingTime
    }
}

class EntreeRecipe: Recipe {
    var protein: String

    init(protein: String, name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.protein = protein
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

class VegetableRecipe: Recipe {
    var mainVegetables: [String]

    init(mainVegetables: [String], name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.mainVegetables = mainVegetables
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

class DessertRecipe: Recipe {
    override init(name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }

    // maybe some interesting dessert related methods here...
}

class CakeRecipe: DessertRecipe {
    var cakeFlavor: String
    var icingFlavor: String

    init(cakeFlavor: String, icingFlavor: String, name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.cakeFlavor = cakeFlavor
        self.icingFlavor = icingFlavor
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

class IceCreamRecipe: DessertRecipe {
    var keyFlavors: [String]

    init(keyFlavors: [String], name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.keyFlavors = keyFlavors
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

//: [Previous](@previous) | [Next](@next)


import Foundation
