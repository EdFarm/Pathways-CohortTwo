//: ## Any
/*:
 - Callout(What if...):
 We need to use multiple types, or don't know the types while we're building our code?
 */
let anyArray: [Any] = [entreeRecipe, dessertRecipe, 5, recipe, cakeRecipe, "Another"]

let anyIndex = Int.random(in: 0..<anyArray.count)
let item = anyArray[anyIndex]

// here we use instrospection to determine type of item
if item is Recipe {
  print("I'm a recipe!")
} else if item is EntreeRecipe {
  print("I'm an entree!")
} else if item is DessertRecipe {
  print("I'm a dessert!")
} else if item is CakeRecipe {
  print("I'm a cake!")
} else if item is Int {
  print("I'm an integer!")
} else if item is String {
  print("I'm a string!")
}

// as? is similar to optional use
if let myRecipe = anyArray[0] as? Recipe {
  print("That recipe is \(myRecipe.name)")
} else {
  print("That's not a recipe. Sorry!")
}

// as! is dangerous -- avoid if possible
let aRecipe = anyArray[1] as! Recipe
print("\(aRecipe.name)")

if let aSafeRecipe = anyArray[1] as? Recipe {
  print("\(aSafeRecipe.name)")
}

// this will break -- have fun!
//let anyRecipe = anyArray[1]
//print("\(anyRecipe.name)")

//: if we want to get away from `Any` in our data
let splitDictionary: [String: [Any]] = ["strings": ["hello", "pathways"], "recipes":[entreeRecipe, dessertRecipe, cakeRecipe]]

if let dictionaryRecipes = splitDictionary["recipes"] as? [Recipe] {
  print("hooray!")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
