//: ## Type Inspection
/*:
 - We can use the `is` keyword to "inspect" the type of an instance.
 */

let exampleRecipes: [Recipe] = [entreeRecipe, dessertRecipe, recipe, cakeRecipe]
let randomIndex = Int.random(in: 0..<exampleRecipes.count)
let example = exampleRecipes[randomIndex]

if example is Recipe {
    print("You should cook \(example.name)")
} else {
    print("Not a recipe -- don't cook that!")
}

if example is EntreeRecipe {
    print("Found an excellent entree recipe!")
} else if example is DessertRecipe {
    if example is CakeRecipe {
        print("Found a cool cake recipe!")
    } else if example is IceCreamRecipe {
        print("Found an interesting ice cream recipe!")
    } else {
        print("Found a delicious dessert recipe!")
    }
} else if example is VegetableRecipe {
    print("Found a vibrant veggie recipe!")
} else {
    print("Found a regular recipe.")
}

print("It's called \(example.name)")

//: [Previous](@previous) | [Next](@next)


import Foundation
