//: # Type Casting & Inspection
//: ---
/*:
 ## Lesson Plan
 - Type Inspection
 - Type Casting
 - Any
 */
//: [Previous](@previous) | [Next](@next)
