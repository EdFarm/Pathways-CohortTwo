//: ## Type Casting
/*:
 - How do we use an object after inspecting its type?
 */
func makeCake(cakeRecipe: CakeRecipe) {
    if let icingFlavor = cakeRecipe.icingFlavor {
        print("Let's mix the flavors of \(cakeRecipe.cakeFlavor) and \(icingFlavor) to make a delicious cake!")
    } else {
        print("Even without any icing, the \(cakeRecipe.cakeFlavor) of this cake will be amazing!")
    }
}

let exampleRecipes: [Recipe] = [entreeRecipe, dessertRecipe, recipe, cakeRecipe]

// this won't work... why?
for recipe in exampleRecipes {
    if recipe is CakeRecipe {
        makeCake(cakeRecipe: recipe)
    }
}

// this will... with type casting!
for recipe in exampleRecipes {
//    let myRecipe = recipe as! CakeRecipe // crashes
//    makeCake(cakeRecipe: myRecipe)
    if let myRecipe = recipe as? CakeRecipe {
        makeCake(cakeRecipe: myRecipe)
    }
}

//: [Previous](@previous) | [Next](@next)

import Foundation
