import Foundation

public class Recipe {
    public var name: String
    public var ingredients: [String]
    public var directions: [String]
    public var cookingTime: Int

    public init(name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.name = name
        self.ingredients = ingredients
        self.directions = directions
        self.cookingTime = cookingTime
    }
}

public class EntreeRecipe: Recipe {
    public var protein: String

    public init(protein: String, name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.protein = protein
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

public class VegetableRecipe: Recipe {
    public var mainVegetables: [String]

    public init(mainVegetables: [String], name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.mainVegetables = mainVegetables
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

public class DessertRecipe: Recipe {
    public override init(name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }

    // maybe some interesting dessert related methods here...
}

public class CakeRecipe: DessertRecipe {
    public var cakeFlavor: String
    public var icingFlavor: String?

    public init(cakeFlavor: String, icingFlavor: String?, name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.cakeFlavor = cakeFlavor
        self.icingFlavor = icingFlavor
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

public class IceCreamRecipe: DessertRecipe {
    public var keyFlavors: [String]

    public init(keyFlavors: [String], name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.keyFlavors = keyFlavors
        super.init(name: name, ingredients: ingredients, directions: directions, cookingTime: cookingTime)
    }
}

public let recipe = Recipe(name: "Cheese Biscuits", ingredients: ["1 1/2 cups flour", "1 cup sugar", "1 cup shredded cheddar cheese", "3/4 cup milk (2% works best)", "1 egg, beaten well", "4 tablespoons butter, softened", "1 1/2 teaspoons baking powder", "1/4 teaspoon vanilla"], directions: ["1. Mix all ingredients together. Pour into greased muffin pan and bake at 400 for 15 - 20 minutes.", "2. This recipe make about 12 muffins."], cookingTime: 25)

 public let entreeRecipe = EntreeRecipe(protein: "Chicken Thighs", name: "Lemon Chicken Thighs", ingredients: ["4 skin-on, bone-in chicken thighs", "Kosher salt, freshly ground pepper", "¼ cup white wine vinegar", "4 garlic cloves, crushed", "2 lemons, halved", "1½ tsp. honey", "½ tsp. Aleppo-style pepper", "3 Tbsp. extra-virgin olive oil"], directions: ["Pat chicken thighs dry and season well with salt and black pepper. Place in a large resealable plastic bag and add vinegar. Seal bag and gently massage chicken to ensure all thighs are coated in vinegar. Chill 1 hour.", "Preheat oven to 400°. Remove chicken thighs from bag and pat dry with paper towels. The drier the skin, the crispier it will be when cooked.", "Place chicken thighs, skin side down, in a dry large cast-iron skillet and set over medium heat. Cook undisturbed until they easily release from the pan, about 4 minutes. Continue to cook, moving chicken around occasionally to ensure the skin is cooking evenly, until golden brown, 8–10 minutes. Add garlic and transfer skillet to oven. Bake until chicken is cooked through, 10–12 minutes. Transfer chicken and garlic to a plate.", "Set skillet over medium-high heat and cook lemons, cut side down, until edges are deeply charred (they should be almost black), about 5 minutes. Transfer to plate with chicken and garlic and let cool slightly.", "Squeeze lemon juice into a small bowl; add garlic, honey, and Aleppo-style pepper and whisk to combine. Whisk in oil and any accumulated juices on plate with chicken. Season vinaigrette with salt and black pepper.", "Drizzle half of vinaigrette on a platter and set chicken on top. Serve with remaining vinaigrette alongside."], cookingTime: 30)

 public let dessertRecipe = DessertRecipe(name: "Chocolate Mousse", ingredients: ["1 ⅔ cups heavy cream", "2 tsp. vanilla extract", "½ tsp. kosher salt", "4 egg whites", "½ cup sugar", "6 oz. bittersweet chocolate, melted and cooled", "Chocolate shavings, to garnish"], directions: ["In a large bowl, beat cream, vanilla, and salt with a whisk until stiff peaks form; chill.", "In another large bowl, beat egg whites with a whisk until soft peaks form. While whisking, slowly add sugar, and continue beating until stiff peaks form.", "Add melted chocolate to egg whites, and fold until almost incorporated; add whipped cream and fold until completely incorporated.", "Divide among serving cups; chill.", "Sprinkle with chocolate shavings before serving."], cookingTime: 20)

public let cakeRecipe = CakeRecipe(cakeFlavor: "Yellow Cake", icingFlavor: nil, name: "Dump Cake", ingredients: ["1 pkg yellow cake mix", "1 cup butter", "8 oz. coconut", "20 oz. can of pineapple"], directions: ["Mix pineapple and coconut and spread evenly on the bottom of a greased 9 x 13 inch pan.", "DUMP cake mix evenly over fruit mixture.", "Cover surface with small pieces of butter.", "DON'T MIX!", "Bake at 350F for 45 minutes or until lightly browned.", "Cool and cut into squares.", "Serves 20."], cookingTime: 45)

public let exampleRecipes: [Recipe] = [entreeRecipe, dessertRecipe, recipe, cakeRecipe]

public func randomRecipe() -> Recipe {
    let randomIndex = Int.random(in: 0..<exampleRecipes.count)
    return exampleRecipes[randomIndex]
}
