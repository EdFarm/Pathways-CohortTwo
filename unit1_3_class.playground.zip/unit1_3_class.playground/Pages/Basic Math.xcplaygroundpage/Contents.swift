//: ## Basic Math
/*:
 - One of the most common ways to use operators is when doing basic arithmetic
 - Can use raw values (1, 3, 7.2, e.g.) or use constants/variables you have initialized
 */
// what if we bought 2 things for $7 each?
var totalCost = 2 * 7 // multiplication is done with "*" operator
print(totalCost)

// now we can use `totalCost` to do more math
var costPerUnit = totalCost / 2

// another example
var today = 15
var tomorrow = today + 1

// using doubles
var currentDistance = 12.4
let distanceSincePreviousCheck = 3.7
// use current value distance as part of assignment
let originalDistance = currentDistance
currentDistance = currentDistance - distanceSincePreviousCheck
print(currentDistance)
//: [Previous](@previous) | [Next](@next)
