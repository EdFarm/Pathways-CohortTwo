//: ## Order of Operations
//: ### Just like in Math Class!
/*:
- Order from first to last:
  - Operations in parentheses
  - Multiplication and division
  - Addition and subtraction
*/
var orderExample = 2 + 3 * 5 // 3 x 5 = 15, + 2 = 17

print(orderExample)

// remember: parentheses first
orderExample = (2 + 3) * 5 // 2 + 3 = 5, x 5 = 25

print(orderExample)

//: [Previous](@previous) | [Next](@next)


import Foundation
