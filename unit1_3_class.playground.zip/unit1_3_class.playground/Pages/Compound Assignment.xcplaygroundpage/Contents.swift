//: ## Compound Assignment
/*:
- Callout(What if...): There was an more succinct way to use a value while reassigning it?
 */
/*:
- Available operators: `+`, `-`, `*` (multiplication), `/` (division)
*/
var distance = 12.4
let distanceChangeSincePreviousCheck = 3.7

//distance = distance - distanceChangeSincePreviousCheck

// notice the "-" next to the "=" in the next line
distance -= distanceChangeSincePreviousCheck
print(distance)
distance += distanceChangeSincePreviousCheck
print(distance)
//: [Previous](@previous) | [Next](@next)
