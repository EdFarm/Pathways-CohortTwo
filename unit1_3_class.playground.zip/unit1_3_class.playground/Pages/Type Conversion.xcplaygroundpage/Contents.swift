//: ## Type Conversion
//: ### Need another type?
let totalPrice = 23
let numberOfUnits = 5
let pricePerUnit = totalPrice / numberOfUnits
print("Price/Unit Example 1:")
print(pricePerUnit)

let totalPrice2 = 23.00
let numberOfUnits2 = 5.0 // why is this a double?
let pricePerUnit2 = totalPrice2 / numberOfUnits2
print("Price/Unit Example 2:")
print(pricePerUnit2)

let totalPrice3: Double = 23.00
let numberOfUnits3: Int = 5
let pricePerUnit3 = totalPrice3 / Double(numberOfUnits3)

print("Price/Unit Example 3:")
print(pricePerUnit3)

//: [Previous](@previous) | [Next](@next)
