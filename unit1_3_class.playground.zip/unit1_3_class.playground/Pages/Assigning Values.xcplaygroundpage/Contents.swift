//: ## Assigning Values
/*:
 - We've seen this when assigning values to constants and variables
 - "Assigning" a value is another way to say that you are setting that variable or constant to that value
 */
/*:
 - Callout(Operator for assigning values): `=`
 */

let month = "September"

var dayOfTheMonth = 15

print(dayOfTheMonth)

// "assign" a new value to update the variable
dayOfTheMonth = 16

print(dayOfTheMonth)

//: [Previous](@previous) | [Next](@next)


import Foundation
