
//: # Questions?

// printing when multiplying numbers together
let thirty = 3 * 10
print(thirty)
//: [Previous](@previous) | [Next](@next)
