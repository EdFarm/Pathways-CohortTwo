import Foundation

public struct CartItem: CustomStringConvertible {
    public var name: String
    public var price: Double
    public var quantity: Int

    public var subtotal: Double {
        return price * Double(quantity)
    }

    public var description: String {
        return "\(name) - $\(price) x \(quantity) = $\(subtotal)"
    }
}

public let bananas = CartItem(name: "bananas", price: 0.49, quantity: 5)
public let salmon = CartItem(name: "salmon", price: 13.99, quantity: 1)
public let milk = CartItem(name: "milk", price: 5.49, quantity: 2)
public let rice = CartItem(name: "rice", price: 1.79, quantity: 2)
public let brussels = CartItem(name: "brussels sprouts", price: 3.29, quantity: 2)
public let pizza = CartItem(name: "frozen pizza", price: 7.89, quantity: 1)

public let cart = [bananas, salmon, milk, rice, brussels, pizza]
