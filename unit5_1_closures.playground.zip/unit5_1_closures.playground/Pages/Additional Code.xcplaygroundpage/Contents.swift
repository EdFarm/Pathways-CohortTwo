//: [Previous](@previous)

import Foundation

let test = [[1, 2, 3], [4, 5, 6], [1, 7, 4], [8, 3, 2]]

let results = test.reduce([Int]()) { (list, group) -> [Int] in
    return list + group.filter { (number) -> Bool in
        !list.contains(number)
    }
}

//let results = test.reduce([Int]()) { (list, group) -> [Int] in
//    return list + group.filter { !list.contains($0) }
//}

let results2 = test.reduce([Int]()) { $0 + $1 }
    .reduce([Int]()) { $0.contains($1) ? $0 : $0 + [$1] }

print(results2)

print(results)

//: [Next](@next)
