/*:
 Playground originally constructed for use as part of Ed Farm's Pathways program. [edfarm.org](https://edfarm.org)

 Taylor Smith
 - Callout(Email):
 [info@outriggerdigital.com](mailto:info@outriggerdigital.com)

 */
/*:
 - Callout(Twitter):
 [@rendersmith](https://twitter.com/rendersmith)
 */
/*:
 - Callout(Copyright 2020):
 Outrigger Digital LLC
 */
