//: ## Closures as Arguments
/*:
 - Closures can be passed into functions/methods as an argument
 - Allows for additional, customizable behavior to be added to a function

 - callout(What if...): We needed to sort the items in our cart?
 */
// use cart.sort()
//: [Previous](@previous) | [Next](@next)
import Foundation
