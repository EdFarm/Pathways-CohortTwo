//: ## Getting Closure
/*:
 - What's a closure?
 - Why are closures useful?
 - How do we use closures?
 - Using closures with map, filter, and reduce
 */
//: [Previous](@previous) | [Next](@next)


import Foundation
