//: ## Syntactic Sugar
/*:
 - More concise code that has the same effect as before
 - Brevity comes with complexity when reading
 */
// removing parentheses

// return type inference

// trailing syntax

// placeholder names

// capture
//: [Previous](@previous) | [Next](@next)


import Foundation
