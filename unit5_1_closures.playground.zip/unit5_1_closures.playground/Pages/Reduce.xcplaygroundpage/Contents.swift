//: ## Closures and `reduce()`
/*:
 - `reduce()` allows us to use all values in a collection to reach a single value
 - the result is another collection containing the same type as the original collection
 - result begins with an initial value argument
 */
var total: Double = 0
for item in cart {
    total += item.subtotal
}
print(total)

//: let's do the same work with `reduce()`...

//: [Previous](@previous) | [Next](@next)

import Foundation
