//: ## Closures and `map()`
/*:
 - `map()` allows us to run a closure on each value inside a collection
 - the result is another collection containing the type returned by the closure
 - useful for removing/simplifying `for` loops
 */
var capitalizedItems: [String] = []
for item in cart {
    let capitalizedItem = item.name.capitalized
    capitalizedItems.append(capitalizedItem)
}

print(capitalizedItems)

//: let's do the same work with `map()`...

//: [Previous](@previous) | [Next](@next)


import Foundation
