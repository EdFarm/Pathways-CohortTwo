//: ## Closures and `filter()`
/*:
 - `filter()` allows us to remove/retain items in a collection based on the `bool` return value of a closure
 - the result is another collection containing the same type as the original collection
 */
var loopedItems: [CartItem] = []

for item in cart {
    if item.name.first == "b" {
        loopedItems.append(item)
    }

//    if item.price >= 5.00 {
//        loopedItems.append(item)
//    }
}

print(loopedItems)

//: let's do the same work with `filter()`...


//: [Previous](@previous) | [Next](@next)
import Foundation
