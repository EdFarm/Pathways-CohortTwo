//: ## Function Design
/*:
- Swift allows us to make a few decisions about the style our functions have
 - Some of these impact the way the functions work, others are more about code style
 - External parameter naming, omitting labels, and default values are all part of this
 - Parameters with default values don't require a value to be included when calling the function
 - Swift allows for omitting `return` in single line functions
 */
func precipitationChance(morningChance morning: Double, afternoonChance afternoon: Double) -> Double {
    // get the average of the sample that there will precipitation
    let numberOfSamples: Double = 2
    let averageChance = (morning + afternoon) / numberOfSamples
    return averageChance;
}

func sendMessage(to recipient: String) {
    print("Hello, \(recipient)")
}

sendMessage(to: "Taylor")

let chance = precipitationChance(morningChance: 0.5, afternoonChance: 0.9)

func reportWeather(highTemperature: Int, lowTemperature: Int, weatherDescription: String = "sunny") {
//    var description = weatherDescription
//    if (highTemperature >= 80) {
//        description += " and HOT"
//    }
    print("Today's weather will be \(weatherDescription) with a high of \(highTemperature) degress and a low of \(lowTemperature) degrees!")
}

reportWeather(highTemperature: 81, lowTemperature: 65, weatherDescription: "rainy")

func sayHelloTo(_ className: String) {
    print("Hello \(className)")
}

sayHelloTo("Pathways")

func getWeatherReport(highTemperature: Int, lowTemperature: Int, weatherDescription: String = "sunny") -> String {
    "Today's weather will be \(weatherDescription) with a high of \(highTemperature) degress and a low of \(lowTemperature) degrees!"
}

func reportWeather2(highTemperature: Int, lowTemperature: Int, weatherDescription: String = "sunny") {
    func addNumbers(a: Int, b: Int) -> Int {
        return a + b
    }

    print(addNumbers(a: 1, b: 7))

    let weatherReport = getWeatherReport(highTemperature: highTemperature, lowTemperature: lowTemperature, weatherDescription: weatherDescription)
    print(weatherReport)
}

print(getWeatherReport(highTemperature: 45, lowTemperature: 30))
//: [Previous](@previous) | [Next](@next)
