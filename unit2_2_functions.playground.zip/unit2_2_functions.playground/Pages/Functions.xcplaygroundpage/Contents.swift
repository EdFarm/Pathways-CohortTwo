//: ## Functions
/*:
 - We've talked about DATA a lot so far
 - Functions are all about BEHAVIOR
 - Functions allow you to wrap common behavior in a reusable package
 - When you use a function, it's common to say that you are "calling" that function
 */
//: We've seen a lot of one function, `print()`
print("Hello, Pathways!")
//: [Previous](@previous) | [Next](@next)


import Foundation
