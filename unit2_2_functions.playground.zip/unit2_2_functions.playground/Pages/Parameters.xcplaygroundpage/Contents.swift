//: ## Parameters
//: ### Data In
/*:
 - Parameters allow us to send data to the function to be used as part of the work to be done
 - Parameters are specified with a name and are annotated with a type, much like constants and variables
 - A function can have multiple parameters, separated by commas `,` each with their own name and type.
 */
func reportWeather(highTemperature: Int, lowTemperature: Int, weatherDescription: String) {
    print("Today's weather will be \(weatherDescription) with a high of \(highTemperature) degress and a low of \(lowTemperature) degrees!")
}

reportWeather(highTemperature: 80, lowTemperature: 60, weatherDescription: "sunny")
reportWeather(highTemperature: -1, lowTemperature: -12, weatherDescription: "icy")

//: what other parameters could we add?

//: [Previous](@previous) | [Next](@next)
