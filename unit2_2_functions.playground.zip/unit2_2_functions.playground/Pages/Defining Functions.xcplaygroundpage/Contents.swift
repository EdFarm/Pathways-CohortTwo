//: ## Defining Functions
//: ### What the `func`
/*:
 A function can be defined like this

        func functionName(parametersGoHere) -> ReturnType {
            // do some work here...
        }
 - Note the `func` keyword
 - Parentheses `()` are used to hold the parameters
 - An arrow `->` points to the return type, if the function returns data
 - Just like our `if-else` expressions, the block of code that is executed is contained in curly braces `{}`
 */
func reportWeather() {
    print("Today's weather will be sunny with a high of 72 degress and a low of 55 degrees!")
}

reportWeather()
//: this is probably pretty boring unless we live in San Diego... we'll need to change that String with some data...

//: [Previous](@previous) | [Next](@next)


import Foundation
