//: ## Returning Values
//: ### Data In, Data Out
/*:
- Functions are able to `return` a value to us as a result of the execution of the function
 - The type of the return value is specified in the function definition
 */
//: Let's assume we have two samples indicating daily chance of precipation and want to show the user the average of those two...
func precipitationChance(morningChance: Double, afternoonChance: Double) -> Double {
    // get the average of the "chances" that there will precipitation
    let numberOfSamples: Double = 2
    let averageChance = (morningChance + afternoonChance) / numberOfSamples
    return averageChance
}

let todaysChance = precipitationChance(morningChance: 0.5, afternoonChance: 0.25)

print(todaysChance)
//: [Previous](@previous) | [Next](@next)
