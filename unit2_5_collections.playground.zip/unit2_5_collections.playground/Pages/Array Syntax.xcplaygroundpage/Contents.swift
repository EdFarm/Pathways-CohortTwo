//: ## Defining Arrays
/*:
 - Arrays contain **ordered** collections of items
 - **Type Safety** - All items in the array are expected to be the same type
 - Type can be inferred or annotated as needed
 */
let strArray: [String] = ["I", "am", "a", "string", "array", "!"]
var charArray: [Character] = ["A", "B", "C", "D"]
var strArray2 = ["This", "is", "another", "string", "array"]
var intArray = [1, 2, 3, 4, 5, 6]

var boolArray = [true, false, false, true, true]

var myArray: [String] = []
//: [Previous](@previous) | [Next](@next)


import Foundation
