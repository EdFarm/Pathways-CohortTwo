//: ## Removing Items from Arrays
/*:
 */
var names = ["Janet", "Bill", "Rosie"]
names.insert("David", at: 2)

print("\(names) <- Before")
names.remove(at: 3)
print("\(names) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
