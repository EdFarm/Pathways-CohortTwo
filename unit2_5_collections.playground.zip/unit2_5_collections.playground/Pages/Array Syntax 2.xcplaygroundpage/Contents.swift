//: ## Defining Arrays
//: What about an array of booleans?
var boolArray: [Bool]
let bool1 = true
let bool2 = false
boolArray = [bool1, bool2, false]
//: [Previous](@previous) | [Next](@next)


import Foundation
