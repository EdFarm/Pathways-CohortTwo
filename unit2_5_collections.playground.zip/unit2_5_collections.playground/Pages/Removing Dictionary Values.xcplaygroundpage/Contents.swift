//: ## Removing Dictionary Values
/*:
 - Set the `value` for a `key` to `nil` to remove it
 */
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309"]

contacts["Steve"] = "AEIOU2468"

print("\(contacts) <- Before")
contacts["Janet"] = nil // Removing an element
print("\(contacts) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
