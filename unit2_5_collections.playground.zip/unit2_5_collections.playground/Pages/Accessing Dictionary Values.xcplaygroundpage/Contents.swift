//: ## Accessing Dictionary Values
/*:
 - Use _subscript_ syntax with the `key` to access the value
 */
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309"]

// Accessing an element
if let janetPhone = contacts["Janet"] {
  print(janetPhone)
}

print(contacts.count)

//print(contacts.keys)
let keys = Array(contacts.keys)
// ["Janet", "Bill", "Rosie"]
print(keys)
// keys[1] == "Bill"
print(keys[1]) // array index 1
print(contacts[keys[1]]!)
// contacts["Bill"] == "222-333-4444"
print(contacts.values)

//: [Previous](@previous) | [Next](@next)


import Foundation
