//: ## Dictionaries
/*:
 - Dictionaries are collections of `key: value` pairs
 - Useful for modeling more complex data without creating new types
 - No duplicate keys
 - Dictionaries are **unordered**
 */
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309"]
print(contacts)
var myDictionary = [String: String]() // ["name": "busID"]
var myDictionary2 = Dictionary<String, Int>() // ["myName": 5]
var myDictionary3: [Int: String] = [:] // [12345: "Hello"]
var myDictionary4: Dictionary<String, Int> = [:]
//: [Previous](@previous) | [Next](@next)


import Foundation
