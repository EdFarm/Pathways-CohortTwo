//: ## Adding Values and Modifying Dictionaries
/*:
 - Syntax for addition or modification is the same
 - Use the `key` to add or modify a value for that `key`
 */
var contacts = ["Janet": "111-111-1111", "Bill": "222-333-4444", "Rosie": "205-867-5309"]

contacts["Steve"] = "AEIOU2468" // Adding an element

print("\(contacts) <- Before")
contacts["Janet"] = "555-666-7777" // Modifying an element
print("\(contacts) <- After")
contacts.updateValue("12345", forKey: "Steve")
print(contacts)
//: [Previous](@previous) | [Next](@next)


import Foundation
