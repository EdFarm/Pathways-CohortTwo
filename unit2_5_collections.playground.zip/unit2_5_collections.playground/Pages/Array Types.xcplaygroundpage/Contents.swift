//: ## Array Types
/*:
 - There are several ways to define the type for an array
 */

var intArray: [Int] = []

var strArray: Array<String> =  []

var boolArray = [Bool]()

var anyArray: [Any] = ["hello", 1, 2, 3.4, false] // beware the Any type

//: [Previous](@previous) | [Next](@next)

