//: ## Inserting Items into Arrays
/*:
 */
var names = ["Janet", "Bill", "Rosie"]

print("\(names) <- Before")

names.insert("David", at: 2)

print("\(names) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
