//
//  ViewController.swift
//  VCLifeCycle
//
//  Created by Taylor Smith on 10/26/20.
//

import UIKit

class ViewController: UIViewController {
    // first
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // second
//    override func viewWillAppear(_ animated: Bool) {
//        <#code#>
//    }
//
//    // third
//    override func viewDidAppear(_ animated: Bool) {
//        <#code#>
//    }
//
//    // fourth
//    override func viewWillDisappear(_ animated: Bool) {
//        <#code#>
//    }
//
//    // fifth
//    override func viewDidDisappear(_ animated: Bool) {
//        <#code#>
//    }
}

