//
//  ThanksViewController.swift
//  seguesDemo
//
//  Created by Taylor Smith on 10/22/20.
//

import UIKit

class ThanksViewController: UIViewController {
    var emailText: String = ""
    @IBOutlet weak var emailLabel: UILabel!

    override func viewDidLoad() {
        emailLabel!.text = emailText
    }
}


