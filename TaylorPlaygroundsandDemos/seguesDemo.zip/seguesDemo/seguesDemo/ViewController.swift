//
//  ViewController.swift
//  seguesDemo
//
//  Created by Taylor Smith on 10/22/20.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var segueSwitch: UISwitch!
    @IBOutlet weak var emailTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // guard against a nil segue.identifier
        guard let segueID = segue.identifier else {
            return
        }

        switch segueID {
        case "thanksSegue":
            // optional binding
            if let text = emailTextField!.text,
               // optional type casting
               let destination = segue.destination as? ThanksViewController {
                destination.emailText = text
            }
        // for more segue identifiers
        // case "anotherSegueID":
        default:
            print("nothing to see here")
        }
    }

    @IBAction func unwindToHome(_ unwindSegue: UIStoryboardSegue) {
    }

    @IBAction func unwindToAnotherPlace(_ unwindSegue: UIStoryboardSegue) {
        // if you need to do something... here you go
        // refresh the page from the server
    }

    @IBAction func triggerSegue(_ sender: UIButton) {
        if segueSwitch.isOn {
            // trigger yellow segue
            performSegue(withIdentifier: "yellowSegue", sender: nil)
        } else {
            // trigger pink segue
            performSegue(withIdentifier: "pinkSegue", sender: nil)
        }
    }

}

