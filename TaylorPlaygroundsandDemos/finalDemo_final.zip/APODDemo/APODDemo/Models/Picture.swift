//
//  Picture.swift
//  APODDemo
//
//  Created by Taylor Smith on 11/10/20.
//

import UIKit

struct Picture {
    var title: String
    var thumbnail: String?
    var hdurl: String?
    var url: String
    var text: String
    var type: String
    var link: String
    var date: String
    var copyright: String
}

extension Picture: Codable {
    enum CodingKeys: String, CodingKey {
        case title
        case hdurl
        case url
        case date
        case copyright
        // case propertyName = "jsonName"
        case text = "description"
        case type = "media_type"
        case link = "apod_site"
    }
}
