//
//  ViewController.swift
//  APODDemo
//
//  Created by Taylor Smith on 11/10/20.
//

import UIKit
import SDWebImage

class ViewController: UITableViewController {
    var pictures: [Picture] = []
    var networkController: Networkable = NetworkController()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.refreshControl = UIRefreshControl()
        // pull to refresh setup...
        tableView.refreshControl?.addTarget(self, action: #selector(refreshTable), for: .valueChanged)
        // Do any additional setup after loading the view.
        // load data here...
        fetchImages()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailSegue" {
            guard let destination = segue.destination as? DetailViewController, let sender = sender as? Picture else {
                return
            }

            destination.picture = sender
        }

    }

    func fetchImages() {
        networkController.fetchList(count: 10) { (pictures) in
            self.pictures = pictures
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pictures.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "baseCell")!
        let rowPicture = pictures[indexPath.row]

        cell.textLabel?.text = rowPicture.title
        cell.detailTextLabel?.text = rowPicture.date

        guard let url = URL(string: rowPicture.url) else {
            cell.imageView?.image = UIImage(systemName: "photo")
            return cell
        }

        cell.imageView?.sd_setImage(
            with: url,
            placeholderImage: UIImage(systemName: "photo")) { _, _, _, _ in
            tableView.reloadRows(at: [indexPath], with: .none)
        }
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rowPicture = pictures[indexPath.row]
        performSegue(withIdentifier: "detailSegue", sender: rowPicture)
    }

    // pull to refresh action
    @objc func refreshTable() {
        fetchImages()
        DispatchQueue.main.async {
            self.tableView.refreshControl?.endRefreshing()
        }
    }
}
