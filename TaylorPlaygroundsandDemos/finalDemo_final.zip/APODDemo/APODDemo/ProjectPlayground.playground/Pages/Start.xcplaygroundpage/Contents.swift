import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true
//PlaygroundPage.current.finishExecution()
// Using https://apodapi.herokuapp.com to fetch data and build list

// URL components
let protocolString = "https://"
let subdomain = "apodapi"
let domain = "herokuapp.com"
let path = "/api"

// https://www.apple.com/
// https://apodapi.herokuapp.com/api?count=25

let urlString = "\(protocolString)\(subdomain).\(domain)\(path)"

var url = URL(string: urlString)!
print(url.absoluteString)

extension URL {
    func withQueries(_ queries: [String: String]) -> URL? {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map({ (key, value) -> URLQueryItem in
            return URLQueryItem(name: key, value: value)
        })
        return components?.url
    }
}

let queryDictionary: [String: String] = [
    "count": "1",
//    "start_date": "2020-01-01",
//    "end_date": "2020-11-12"
]

url = url.withQueries(queryDictionary)!
print(url.absoluteString)

let request = URLSession.shared.dataTask(with: url) { data, response, error in
    //    if let data = data {
    ////        print(data)
    //        print(data as NSData)
    //    }

//        if let data = data,
//           let string = String(data: data, encoding: .utf8) {
//            print(string)
//        }

//    print("decoding")
//    let jsonDecoder = JSONDecoder()
//    if let data = data {
//        print("have data!")
//        if let string = String(data: data, encoding: .utf8) {
//            print(string)
//        }
//
//        if let results = try? jsonDecoder.decode([String: String].self, from: data) {
//        }

    // exception/error handling
//    if let data = data {
//        let results: [[String: String]]
//        do {
//            results = try jsonDecoder.decode([[String: String]].self, from: data)
//        } catch {
//            print(error)
//        }
//    }
//    }
        let jsonDecoder = JSONDecoder()
        if let data = data,
           let results = try? jsonDecoder.decode([[String: String]].self, from: data) {
            print(results)
        }
    PlaygroundPage.current.finishExecution()
}

request.resume()

// do something else...
