import Foundation

public class Bus: CustomStringConvertible {
  public var number: String
  public var mileage: Int = 0
  
  public init(number: String, mileage: Int = 0) {
    self.number = number
    self.mileage = mileage
  }
  
  public var description: String {
    return "Bus \(number) has a mileage of \(mileage)"
  }
}

public class Person {
  public var firstName: String
  public var lastName: String?
  
  public init(firstName: String, lastName: String?) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

public class User: Person {
  public var email: String
  
  public init(email: String, firstName: String, lastName: String?) {
    self.email = email
    super.init(firstName: firstName, lastName: lastName)
  }
}

public class Student: Person {
  public var bus: Bus?
  
  public init(bus: Bus?, firstName: String, lastName: String?) {
    self.bus = bus
    super.init(firstName: firstName, lastName: lastName)
  }
}

public class Driver: User {
  public var bus: Bus?
  
  public init(bus: Bus?, email: String, firstName: String, lastName: String?) {
    self.bus = bus
    super.init(email: email, firstName: firstName, lastName: lastName)
  }
}

public class Parent: User {
  public var students: [Student]
  
  public init(students: [Student], email: String, firstName: String, lastName: String?) {
    self.students = students
    super.init(email: email, firstName: firstName, lastName: lastName)
  }
}

public let bus1 = Bus(number: "ABC123")
public let driver1 = Driver(bus: bus1, email: "janet@example.com", firstName: "Janet", lastName: "Walker")

public let bus2 = Bus(number: "XYZ987")
public let driver2 = Driver(bus: bus2, email: "bill@example.com", firstName: "Bill", lastName: "Jenkins")
public let drivers = [driver1, driver2]
