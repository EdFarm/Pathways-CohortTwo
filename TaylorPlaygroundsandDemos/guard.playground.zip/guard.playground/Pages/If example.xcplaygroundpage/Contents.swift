//: ## Guard
/*:
 - Callout(Sometimes...):
 If-else statements can get complicated...
 */
let day = "Tuesday"
let studentsPresent = 0
let computerSetUp = true

func teachSwift() {
  if day == "Tuesday" || day == "Thursday" {
    if studentsPresent > 0 {
      if computerSetUp {
        print("Let's learn some Swift!") // happy path
      } else {
        print("Set up the computer!")
        return // sad path
      }
    } else {
      print("No students present!")
      return // sad path
    }
  } else {
    print("No class tonight!") // sad path
  }
  print("I'm still running...")
}

teachSwift()

//: [Previous](@previous) | [Next](@next)


import Foundation
