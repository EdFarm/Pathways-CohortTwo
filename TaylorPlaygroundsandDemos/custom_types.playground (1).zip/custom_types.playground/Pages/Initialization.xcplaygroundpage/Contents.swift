//: ## Initialization
/*:
 - We can create an **instance** of our struct
 - After _initializing_ (or _instantiating_) we can access its properties using dot (`.`) syntax.
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int
    var audio: Data
    var episodeTitle: String
}

let podcastEpisode = Podcast(podcastTitle: "Taylor's Swift", episodeNumber: 123, audio: Data(), episodeTitle: "Structures and Classes")

print(podcastEpisode.episodeTitle)

/*:
 - Callout(Alternate Syntax):
 `Podcast.init()` is another way to initialize, but the `.init` is not required and not often used
 */
//: [Previous](@previous) | [Next](@next)
