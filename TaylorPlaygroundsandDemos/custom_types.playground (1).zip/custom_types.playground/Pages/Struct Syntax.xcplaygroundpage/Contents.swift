/*:
 ## Structs
 ### Basic Syntax
 - Structures introduce a new keyword, `struct`
 - Structs allow us to build new **types** (Like `String`, `Int`, `Bool`, etc.)
 - Structs can have **data** _and_ **behavior**
 
 ---
 Structs are named

 The Podcast `struct` below only has properties at the moment
 */

import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int
    var audio: Data
}
//: - Callout(Next Steps):
//: What if we wanted to store `episodeTitle`?
//:
//: [Previous](@previous) | [Next](@next)
