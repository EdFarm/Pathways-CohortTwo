//: ## Overriding Methods
/*:
 - A superclass method can be **overridden** using the `override` keyword
 - This replaces the behavior of the base class's method with your own
 */
class Employee: User {
    var salary: Int
  
  init(firstName: String, lastName: String, salary: Int) {
    self.salary = salary
    super.init(firstName: firstName, lastName: lastName)
  }
  
  override func displayName() -> String {
    return "\(lastName), \(firstName)"
  }
}
let user = User(firstName: "Taylor", lastName: "Swift")
print(user.displayName())

let employee = Employee(firstName: "Dominic", lastName: "Torretto", salary: 50000)
print(employee.displayName())
//: [Previous](@previous) | [Next](@next)
