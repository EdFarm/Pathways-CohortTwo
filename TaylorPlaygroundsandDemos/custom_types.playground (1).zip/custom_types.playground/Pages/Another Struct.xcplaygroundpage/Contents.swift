//: ## Another Struct
/*:
 - Callout(What if...):
 We need to handle the concept of users in our app...
 */
struct User {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

let user = User(firstName: "Dominic", lastName: "Torretto")
print(user.firstName)
//: [Previous](@previous) | [Next](@next)
