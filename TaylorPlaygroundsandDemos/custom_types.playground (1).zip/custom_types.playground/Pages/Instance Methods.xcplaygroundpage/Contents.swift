//: ## Methods
/*:
 - Functions contained within a type are called **methods**
 - Instance methods give _behavior_ to your types
 - Instances of a type _call_ the methods, and may use the properties of that specific instance
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int = 0
    var audio: Data
    var episodeTitle: String
    var lengthInSeconds: Int

    func lengthInMinutes() -> Double {
        return Double(lengthInSeconds) / 60.0
    }
}

let podcastEpisode = Podcast(podcastTitle: "Taylor's Swift", episodeNumber: 123, audio: Data(), episodeTitle: "Structures and Classes", lengthInSeconds: 3672)

print(podcastEpisode.lengthInMinutes())
//: [Previous](@previous) | [Next](@next)
