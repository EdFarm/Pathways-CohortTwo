//: ## Property Observers
/*:
 -
 */
class User {
    var firstName: String
    var lastName: String
    var email: String {
        willSet {
            print("willSet: Email is \(email) and will be updated to: \(newValue)")
        }
        didSet {
            // rough validation of email
            if (email.isEmpty) {
                email = oldValue
            } else {
                // if email is valid, notify user at old email address
                print("didSet: Sending email to \(oldValue) to notify user that email has changed to \(email)")
            }
        }
    }

    init(firstName: String, lastName: String, email: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
    }
}

let user = User(firstName: "Taylor", lastName: "Swift", email: "swift@example.com")
user.email = "test@example.com"

//: [Previous](@previous) | [Next](@next)
