//: ## Classes
/*:
 - Callout(Differences):
 The only difference from [Previous](@previous) is the `class` keyword
 */
class User {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

let user = User(firstName: "Dominic", lastName: "Torretto")
print(user.firstName)
//: [Previous](@previous) | [Next](@next)
