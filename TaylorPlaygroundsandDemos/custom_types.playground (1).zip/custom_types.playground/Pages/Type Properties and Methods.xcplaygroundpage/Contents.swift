//: ## Type Properties and Methods
/*:
 - The `static` keyword indicates a type property or method
 - Type properties are methods are "one per type"
 - They are used/called by using the type name, instead of an instance name
 */
struct Temperature {
    static let boilingPointOfWater: Double = 100

    var celsiusTemperature: Double

    var isBoiling: Bool {
        return celsiusTemperature > Temperature.boilingPointOfWater
    }

    static func convertToFahrenheit(celsius: Double) -> Double {
        return celsius * (9/5) + 32
    }
}

Temperature.boilingPointOfWater
Temperature.convertToFahrenheit(celsius: 100)

class User {
    static let someProperty = "Some Type Property"

    var firstName: String
    var lastName: String
    var email: String {
        willSet {
            print("Email will be updated to: \(newValue)")
        }
        didSet {
            if (email.isEmpty) {
                email = oldValue
            } else {
                print("sending email to \(oldValue) to notify user that email has changed to \(email)")
            }
        }
    }

    init(firstName: String, lastName: String, email: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
    }
}

let user = User(firstName: "Test", lastName: "User", email: "test@example.com")
User.someProperty
print(User.someProperty)
//: [Previous](@previous) | [Next](@next)
