//: ## Using "self"
/*:
 - Inside of an instance, `self` refers to that instance
 - Not required **EXCEPT** when you need to clarify ambiguity
 - Our argument names and property names are the same in the initializer, so we must use `self` to disambiguate
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int
    var audio: Data
    var episodeTitle: String

    init(podcastTitle: String, episodeNumber: Int, audio: Data, episodeTitle: String) {
        self.podcastTitle = podcastTitle
        self.episodeNumber = episodeNumber
        self.audio = audio
        self.episodeTitle = episodeTitle
    }
}

let podcastEpisode = Podcast(podcastTitle: "The EdFarm Edition", episodeNumber: 123, audio: Data(), episodeTitle: "Structures and Classes")

print(podcastEpisode.episodeTitle)
//: [Previous](@previous) | [Next](@next)
