//: ## Default Values
/*:
 - You can set a default value for a property
 - A default value does not have to be included in an initializer
 - If all of the properties have a default value, the empty initializer becomes available
 - Below, `episodeNumber` has been given a default of `0`
 */
import Foundation

struct Podcast {
    var podcastTitle: String = ""
    var episodeNumber: Int = 0
    var audio: Data = Data()
    var episodeTitle: String
}

 let techPodcastEpisode = Podcast(podcastTitle: "The EdFarm Edition",  episodeTitle: "Structs and Classes")

print(techPodcastEpisode.episodeTitle)
 let cookingPodcastEpisode = Podcast(podcastTitle: "The Tasty Taco", episodeNumber: 123, episodeTitle: "Tacos - Sandwiches or Not?")

//: [Previous](@previous) | [Next](@next)
