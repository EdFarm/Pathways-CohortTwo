//: ## Inheritance of methods
/*:
 - Note:
 Here, we use the base class's `displayName()` method
 */
class Employee: User {
    var salary: Int

  init(firstName: String, lastName: String, salary: Int) {
    self.salary = salary
    super.init(firstName: firstName, lastName: lastName)
  }
}

let employee = Employee(firstName: "Dominic", lastName: "Torretto", salary: 50000)
print(employee.displayName())
//: [Previous](@previous) | [Next](@next)
