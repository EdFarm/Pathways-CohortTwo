//: ## Custom Initializers
/*:
 - In addition to the memberwise initializers, you can write your own
 - If you include a custom initializer, the Swift generated memberwise initializer is removed
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int
    var audio: Data
    var episodeTitle: String

    init(podcastTitle: String, episodeNumber: Int, episodeTitle: String) {
        self.podcastTitle = podcastTitle
        // what if a negative episode number was entered?
        if (episodeNumber < 1) {
            self.episodeNumber = 0
        } else {
            self.episodeNumber = episodeNumber
        }
        self.audio = Data()
        self.episodeTitle = episodeTitle
    }
}

let podcastEpisode = Podcast(podcastTitle: "The EdFarm Edition", episodeNumber: -456, episodeTitle: "Structures and Classes")

print(podcastEpisode.episodeNumber)

//: [Previous](@previous) | [Next](@next)
