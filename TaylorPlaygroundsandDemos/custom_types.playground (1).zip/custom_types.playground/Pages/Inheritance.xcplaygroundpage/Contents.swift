//: ## Inheritance
/*:
 - Classes have a superpower - **Inheritance**
 - Subclasses (children) can use the properties and methods of their superclasses (parents)
 - Here, we have a `Employee` subclass of `User`
 */
/*

 User (firstName, lastName)
    - Employee (firstName, lastName, salary)
        - Manager(firstName, lastName, salary, [Employee])
    - Customer (firstName, lastName, email, address)
 */

class Employee: User {
    var salary: Int
  
  init(firstName: String, lastName: String, salary: Int) {
    self.salary = salary
    // superclass initializer
    super.init(firstName: firstName, lastName: lastName)
  }
}

let employee = Employee(firstName: "Dominic", lastName: "Torretto", salary: 50000)
let user = User(firstName: "Letty", lastName: "Torretto")
print(employee.salary)
print(employee.firstName)
//: [Previous](@previous) | [Next](@next)
