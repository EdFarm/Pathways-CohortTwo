//: ## Superclass Methods
/*:
 - Callout(Differences):
 We've added the `displayName()` method to our base class
 */
class User {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
  
  func displayName() -> String {
    return "\(firstName) \(lastName)"
  }
}

class Employee: User {
    var salary: Int

  init(firstName: String, lastName: String, salary: Int) {
    self.salary = salary
    // superclass initializer
    super.init(firstName: firstName, lastName: lastName)
  }
}

let user = User(firstName: "Dominic", lastName: "Torretto")
print(user.displayName())
let employee = Employee(firstName: "Brian", lastName: "Spilner", salary: 50000)
print(employee.displayName())
//: [Previous](@previous) | [Next](@next)
