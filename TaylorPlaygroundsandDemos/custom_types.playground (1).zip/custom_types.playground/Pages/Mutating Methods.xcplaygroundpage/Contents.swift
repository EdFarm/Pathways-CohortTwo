//: ## Mutating Methods
/*:
 - Use the `mutating` keyword at the beginning of a method definition to indicate that it can modify a property
 - A variable instance of a type is required to use mutating methods
 - `mutating` is not required in classes
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int = 0
    var audio: Data
    var episodeTitle: String
    var lengthInSeconds: Int

    mutating func extendPodcastLengthBy(minutes: Double) {
        let seconds = minutes * 60
        lengthInSeconds += Int(seconds.rounded())
    }
}

var podcastEpisode = Podcast(podcastTitle: "Taylor's Swift", episodeNumber: 123, audio: Data(), episodeTitle: "Structures and Classes", lengthInSeconds: 3660)

podcastEpisode.extendPodcastLengthBy(minutes: 20)
print(podcastEpisode.lengthInSeconds)
//: [Previous](@previous) | [Next](@next)
