//: ## Properties
/*:
- Data for a struct is stored in **properties**
- Properties can be any type
- Properties are `camelCased`
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int
    var audio: Data
    var episodeTitle: String
}
//: - Callout(Next Steps):
//: Cool... but how do we make a `Podcast`?
//:
//: [Previous](@previous) | [Next](@next)
