//: ## More  Subclasses
/*:
 - Callout(What if...):
 What if we need a `Customer` who needs to have address information, but should also get the features of `User`?
 Are there other roles of `User` we have in our app?
 */
class Customer: User {
    var streetAddress: String
    var city: String
    var state: String
    var postalCode: String

    init(firstName: String, lastName: String, streetAddress: String, city: String, state: String, postalCode: String) {
        self.streetAddress = streetAddress
        self.city = city
        self.state = state
        self.postalCode = postalCode
        super.init(firstName: firstName, lastName: lastName)
    }

    func displayAddress() -> String {
        "\(streetAddress)\n\(city), \(state) \(postalCode)"
    }
}

let customer = Customer(firstName: "Bill", lastName: "Jenkins", streetAddress: "123 Main Street", city: "Birmingham", state: "AL", postalCode: "35209")
print(customer.displayAddress())

class Manager: User {
    var employeesManaged: [Employee]

    init(firstName: String, lastName: String, employeesManaged: [Employee]) {
        self.employeesManaged = employeesManaged
        super.init(firstName: firstName, lastName: lastName)
    }
  // more code here...
}
//: [Previous](@previous) | [Next](@next)
