import Foundation

open class User {
  public var firstName: String
  public var lastName: String
  
  public init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
  
  public func displayName() -> String {
    return "\(firstName) \(lastName)"
  }
}

public class Employee: User {
    public var salary: Int

    public init(firstName: String, lastName: String, salary: Int) {
        self.salary = salary
        super.init(firstName: firstName, lastName: lastName)
  }
}
