//: ## Computed Properties
/*:
 - A computed property gets its value from other properties in the type
 - 
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int = 0
    var audio: Data
    var episodeTitle: String
    var lengthInSeconds: Int

    // we can make this a computed property instead!
//    func lengthInMinutes() -> Double {
//        return Double(lengthInSeconds) / 60.0
//    }

    var lengthInMinutes: Double {
        return Double(lengthInSeconds) / 60.0
    }
}

var podcastEpisode = Podcast(podcastTitle: "Taylor's Swift", episodeNumber: 123, audio: Data(), episodeTitle: "Structures and Classes", lengthInSeconds: 3660)

print(podcastEpisode.lengthInMinutes)
//: [Previous](@previous) | [Next](@next)
