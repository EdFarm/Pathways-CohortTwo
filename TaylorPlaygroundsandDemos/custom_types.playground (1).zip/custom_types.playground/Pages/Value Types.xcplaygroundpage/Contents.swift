//: ## Value Types
/*:
 - Structs are "Value" types
 - When you make a copy of a value type, you are copying all of the properties into a new instance
 - The two instances can be changed independently
 */
import Foundation

var podcast = Podcast(podcastTitle: "The EdFarm Edition", episodeNumber: 20201001, audio: Data(), episodeTitle: "Structures and Classes")

var podcast2 = podcast

podcast2.episodeTitle = "Collections and Loops"
podcast2.episodeNumber = 20201006

print(podcast2.episodeTitle)
print(podcast.episodeTitle)

//: [Previous](@previous) | [Next](@next)
