import Foundation

public struct Podcast {
    public var podcastTitle: String
    public var episodeNumber: Int = 0
    public var audio: Data
    public var episodeTitle: String

    public init(podcastTitle: String, episodeNumber: Int, audio: Data, episodeTitle: String) {
        self.podcastTitle = podcastTitle
        self.episodeNumber = episodeNumber
        self.audio = audio
        self.episodeTitle = episodeTitle
    }
}
