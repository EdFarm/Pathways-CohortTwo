//: ## Memberwise Initialization
/*:
 - When creating an instance of a struct, we can use a memberwise initalizer
 - A memberwise initializer is created automatically by the Swift compiler
 - Properties are listed in the order they are defined in the struct
 */
import Foundation

struct Podcast {
    var podcastTitle: String
    var episodeNumber: Int
    var episodeTitle: String
    var audio: Data
}

let podcastEpisode = Podcast(podcastTitle: "Taylor's Swift", episodeNumber: 123, episodeTitle: "Structures and Classes", audio: Data())

print(podcastEpisode.podcastTitle)
/*:
 - Important:
 Each property **MUST** have a value after initialization
 */
//: [Previous](@previous) | [Next](@next)
