import Foundation

// Using https://apodapi.herokuapp.com to fetch data and build list

// URL components
let protocolString = "https://"
let subdomain = "apodapi"
let domain = "herokuapp.com"
let path = "/api"
