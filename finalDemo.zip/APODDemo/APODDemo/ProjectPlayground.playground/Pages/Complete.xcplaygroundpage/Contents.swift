import UIKit
import PlaygroundSupport

// discuss playground support and indefinite execution
PlaygroundPage.current.needsIndefiniteExecution = true

// existing model found in Picture.swift file
struct Picture {
    var title: String
    var hdurl: String
    var url: String
    var text: String
    var type: String
    var link: String
    var date: String
    var copyright: String
}

// using an extension to conform to codable protocol
extension Picture: Codable {
    enum CodingKeys: String, CodingKey {
        case title
        case text = "description"
        case hdurl
        case url
        case type = "media_type"
        case link = "apod_site"
        case date
        case copyright
    }
}

// useful extension for managing queryItems
// better than trying to do it yourself with
// strings because not everything in a string
// is supported by a url (think spaces, other characters)
extension URL {
    func withQueries(_ queries: [String: String]) -> URL? {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)

        components?.queryItems = queries.map({ (key, value) -> URLQueryItem in
            return URLQueryItem(name: key, value: value)
        })

        return components?.url
    }
}

// URL components
let protocolString = "https://"
let subdomain = "apodapi"
let domain = "herokuapp.com"
let path = "/api"

// convert this to some useful example
// count
let queryDictionary: [String: String] = [
    "test": "this",
    "out": "yeah"
]

// assembling URL
let urlString = "\(protocolString)\(subdomain).\(domain)\(path)"
print(urlString)

// since we want to know when our URL fails
// we can force unwrap it with !
var url = URL(string: urlString)!

url.withQueries(queryDictionary)

// adding query parameters with our handy extension!
//url = url.withQueries(queryDictionary)!
print(url.absoluteString)

// .dataTask does GET request (just for fetching data)
// this is the type of request a browser makes when
// loading an web page
// other options are PUT, PUSH, DELETE, etc.
let request = URLSession.shared.dataTask(with: url) { data, response, error in
    if let data = data {
        print(data)
//        print(data as NSData)
    }

    // showing JSON
//    if let data = data, let string = String(data: data, encoding: .utf8) {
//        print(string)
//    }

    // decoding JSON into a Dictionary
    // first time we'll get a good look at the structure
    let jsonDecoder = JSONDecoder()
    if let data = data,
       let pictureDictionary = try? jsonDecoder.decode([String: String].self, from: data) {
        print(pictureDictionary)
    }

    // decoding JSON into Picture Struct
//    let jsonDecoder = JSONDecoder()
    if let data = data,
       let picture = try? jsonDecoder.decode(Picture.self, from: data) {
        print(picture.text)
    }

    // be sure to tell the playground page that you're done executing
    PlaygroundPage.current.finishExecution()
}
// can also just add `.resume()` to the end of the line above
request.resume()

