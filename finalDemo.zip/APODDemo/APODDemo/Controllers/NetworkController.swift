//
//  NetworkController.swift
//  APODDemo
//
//  Created by Taylor Smith on 11/10/20.
//

import UIKit

/// Networkable protocol defines the various network endpoints our network controller must conform to
/// by using a protocol, we have the opportunity to provide default behavior via protocol extensions
protocol Networkable {
    func fetchList(count: Int, completion: (_ pictures: [Picture]) -> Void)
}

struct NetworkController: Networkable {
    func fetchList(count: Int, completion: ([Picture]) -> Void) {
        // TODO: build out handling of request to API
        // TODO: process data into expected type
    }
}

/// FakeNetworkController uses the Networkable protocol
/// to build out functional fake data for the app
struct FakeNetworkController: Networkable {
    func fetchList(count: Int, completion: ([Picture]) -> Void) {
        let fakeData = (1...count).map {_ -> Picture in
            let index = Int.random(in: 0..<testData.count)
            return testData.shuffled()[index]
        }

        completion(fakeData)
    }

    private var testData: [Picture] {
        [
            Picture(
                title: "Red Nebula, Green Comet, Blue Stars",
                hdurl: "https://apod.nasa.gov/apod/image/1812/M45-CaliNeb-46P-TomMasterson-GrandMesaObservatory.jpg",
                url: "https://apod.nasa.gov/apod/image/1812/M45-CaliNeb-46P-TomMasterson-GrandMesaObservatory1024.jpg",
                description: "This festively colored skyscape was captured in the early morning hours of December 17, following Comet Wirtanen's closest approach to planet Earth. The comet was just visible to the eye. The lovely green color of its fluorescing cometary atmosphere or coma is brought out here only by adding digital exposures registered on the comet's position below the Pleiades star cluster. The exposures also bring out blue starlight reflected by the dust clouds surrounding the young Pleiades stars. Gaze (toward the left) across dusty dark nebulae along the edge of the Perseus molecular cloud and you'll travel to emission nebula NGC 1499, also known as the California nebula. Too faint for the eye, the cosmic cloud's pronounced reddish glow is from electrons recombining with ionized hydrogen atoms. Around December 23rd, Comet Wirtanen should be easy to find with binoculars when it sweeps close to bright star Capella in the northern winter constellation Auriga, the Charioteer.",
                type: "image",
                link: "https://apod.nasa.gov/apod/ap181220.html",
                date: "2018-12-20",
                copyright: "Tom Masterson (Grand Mesa Observatory)"
            ),
            Picture(
                title: "Deep Magellanic Clouds Image Indicates Collisions",
                hdurl: "https://apod.nasa.gov/apod/image/1607/MagCloudsDeep_BeletskyEtAl_1800.jpg",
                url: "https://apod.nasa.gov/apod/image/1607/MagCloudsDeep_BeletskyEtAl_960.jpg",
                description: "Did the two most famous satellite galaxies of our Milky Way Galaxy once collide? No one knows for sure, but a detailed inspection of deep images like that featured here give an indication that they have. Pictured, the Large Magellanic Cloud (LMC) is on the top left and the Small Magellanic Cloud (SMC) is on the bottom right. The surrounding field is monochrome color-inverted to highlight faint filaments, shown in gray. Perhaps surprisingly, the featured research-grade image was compiled with small telescopes to cover the large angular field -- nearly 40 degrees across. Much of the faint nebulosity is Galactic Cirrus clouds of thin dust in our own Galaxy, but a faint stream of stars does appear to be extending from the SMC toward the LMC. Also, stars surrounding the LMC appear asymmetrically distributed, indicating in simulations that they could well have been pulled off gravitationally in one or more collisions. Both the LMC and the SMC are visible to the unaided eye in southern skies. Future telescopic observations and computer simulations are sure to continue in a continuing effort to better understand the history of our Milky Way and its surroundings.",
                type: "image",
                link: "https://apod.nasa.gov/apod/ap160725.html",
                date: "2016-07-25",
                copyright: "Yuri Beletsky (Carnegie Las Campanas Observatory, TWAN) & David Martinez-Delgado (U. Heidelberg)"
            ),
            Picture(
                title: "Mars and a Colorful Lunar Fog Bow",
                hdurl: "https://apod.nasa.gov/apod/image/1002/marsbow_pacholka_big.jpg",
                url: "https://apod.nasa.gov/apod/image/1002/marsbow_pacholka.jpg",
                description: "Even from the top of a volcanic crater, this vista was unusual. For one reason, Mars was dazzlingly bright two weeks ago, when this picture was taken, as it was nearing its brightest time of the entire year. Mars, on the far upper left, is the brightest object in the above picture. The brightness of the red planet peaked last week near when Mars reached opposition, the time when Earth and Mars are closest together in their orbits. Arching across the lower part of the image is a rare lunar fog bow. Unlike a more commonly seen rainbow, which is created by sunlight reflected prismatically by falling rain, this fog bow was created by moonlight reflected by the small water drops that compose fog. Although most fog bows appear white, all of the colors of the rainbow were somehow visible here. The above image was taken from high atop Haleakala, a huge volcano in Hawaii, USA.",
                type: "image",
                link: "https://apod.nasa.gov/apod/ap100202.html",
                date: "2010-02-02",
                copyright: "Wally Pacholka (AstroPics.com, TWAN)"
            ),
            Picture(
                title: "A Fire Rainbow Over New Jersey",
                hdurl: "https://apod.nasa.gov/apod/image/0806/circumhorizonarc_gitto_big.jpg",
                url: "https://apod.nasa.gov/apod/image/0806/circumhorizonarc_gitto.jpg",
                description: "What is that inverted rainbow in the sky? Sometimes known as a fire rainbow for its flame-like appearance, a circumhorizon arc is created by ice, not fire. For a circumhorizon arc to be visible, the Sun must be at least 58 degrees high in a sky where cirrus clouds are present. Furthermore, the numerous, flat, hexagonal ice-crystals that compose the cirrus cloud must be aligned horizontally to properly refract sunlight like a single gigantic prism. Therefore, circumhorizon arcs are quite unusual to see. Pictured above, however, a rare fire rainbow was captured above trees in Whiting, New Jersey, USA in late May.",
                type: "image",
                link: "https://apod.nasa.gov/apod/ap080610.html",
                date: "2008-06-10",
                copyright: "Paul Gitto (Arcturus Observatory)"
            )
        ]
    }
}


// Using https://apodapi.herokuapp.com to fetch data and build list
// example data
/*
 {
   "apod_site": "https://apod.nasa.gov/apod/ap080610.html",
   "copyright": "Paul Gitto (Arcturus Observatory)",
   "date": "2008-06-10",
   "description": "What is that inverted rainbow in the sky? Sometimes known as a fire rainbow for its flame-like appearance, a circumhorizon arc is created by ice, not fire. For a circumhorizon arc to be visible, the Sun must be at least 58 degrees high in a sky where cirrus clouds are present. Furthermore, the numerous, flat, hexagonal ice-crystals that compose the cirrus cloud must be aligned horizontally to properly refract sunlight like a single gigantic prism. Therefore, circumhorizon arcs are quite unusual to see. Pictured above, however, a rare fire rainbow was captured above trees in Whiting, New Jersey, USA in late May.",
   "hdurl": "https://apod.nasa.gov/apod/image/0806/circumhorizonarc_gitto_big.jpg",
   "media_type": "image",
   "title": "A Fire Rainbow Over New Jersey",
   "url": "https://apod.nasa.gov/apod/image/0806/circumhorizonarc_gitto.jpg"
 },
 */
