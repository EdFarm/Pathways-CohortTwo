//
//  DetailViewController.swift
//  APODDemo
//
//  Created by Taylor Smith on 11/10/20.
//

import UIKit
import SDWebImage

class DetailViewController: UIViewController {
    var picture: Picture?
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var copyrightLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        if let picture = picture {
            if let url = URL(string: picture.url) {
                imageView.sd_setImage(with: url, placeholderImage: UIImage(systemName: "photo"))
            }
            titleLabel.text = picture.title
            dateLabel.text = picture.date
            descriptionTextView.text = picture.description
            copyrightLabel.text = picture.copyright
        }
    }
}
