//
//  Picture.swift
//  APODDemo
//
//  Created by Taylor Smith on 11/10/20.
//

import UIKit

struct Picture {
    var title: String
    var thumbnail: String?
    var hdurl: String?
    var url: String
    var description: String
    var type: String
    var link: String
    var date: String
    var copyright: String
}

// TODO: Make Codable
// TODO: Add codingKeys enum
