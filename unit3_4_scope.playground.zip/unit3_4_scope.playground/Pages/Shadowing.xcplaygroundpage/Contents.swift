//: ## Shadowing
/*:
 - Callout(What if...): We want to use the same variable name inside and outside of a particular scope?
 */
struct User {
    var email: String
    var firstName: String
    var lastName: String
}

let userEmail = "test@example.com"
let testUser = User(email: userEmail, firstName: "Test", lastName: "Example")

func emailUser(_ user: User) {
    let userEmail = user.email

    // do the work of sending an email...
    print("Sent an email to \(user.firstName) \(user.lastName) at \(userEmail)")
}

// run it...
emailUser(testUser)
//: [Previous](@previous) | [Next](@next)


import Foundation
