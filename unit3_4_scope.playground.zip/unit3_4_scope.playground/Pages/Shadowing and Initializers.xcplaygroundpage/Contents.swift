import Foundation
//: ## Shadowing and Initializers
/*:
 - Callout(We've already seen this...): When we use initializers, we've often been using shadowing already.
 */
struct Comment {
  var sender: User
  var note: String
  var sent: Date = Date.init()
  var replies: [Comment] = []
  
  init(_ note: String, sender: User) {
    self.sender = sender
    self.note = note
  }
}

let user = User(email: "awesome@example.com", firstName: "Super", lastName: "Fan")

let comment = Comment("This restaurant is the best! Great service!", sender: user)
//: [Previous](@previous) | [Next](@next)

