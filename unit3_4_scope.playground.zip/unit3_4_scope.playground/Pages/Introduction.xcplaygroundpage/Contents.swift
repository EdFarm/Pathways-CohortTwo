//: # Scope
/*:
 ## Lesson Plan
 - Global Scope
 - Local Scope
 - Variable Shadowing
 */
//: [Previous](@previous) | [Next](@next)
