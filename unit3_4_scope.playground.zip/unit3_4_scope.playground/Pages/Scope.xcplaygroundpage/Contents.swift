//: ## Scope
/*:
 - Callout(How does...): Swift know what it can see outside and inside blocks of code? Look for `{}` to determine blocks of code. This includes structs, classes, functions, if/guard statements, for loops, etc.
 */
let firstName = "Taylor" // global scope

func printName() {
  let lastName = "Smith" // local scope
  print("First firstName: \(firstName)")
  print("First firstName: \(lastName)")
}

printName()

print("Second firstName: \(firstName)")
//print("Second lastName: \(lastName)")

func printNameAgain() {
  let lastName = "Horn"
  print("Third firstName: \(firstName)")
  print("Third lastName: \(lastName)")
}

printNameAgain()
//: [Previous](@previous) | [Next](@next)


import Foundation
