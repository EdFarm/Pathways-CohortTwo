//: ## Control Flow
/*:
 - This is what we can use to give our code more "logic"
 - By leveraging various "conditional statements", we can redirect our code based on values in the data
 */

//: [Previous](@previous) | [Next](@next)


import Foundation
