//: ## Ternary Operator
//: ### Useful for simple conditionals
/*:
 - Sometimes all we have is a small conditional
 - Ternary statements are shorthand that can reduce the code we have to write
 - Not always the simplest syntax to read, so use cautiously
 */
var message: String

let installedVersion = "13.7"
let currentVersion = "14.0"

let isLatestInstalled = installedVersion == currentVersion
let upgradeMessage = "Please install the latest version."
let currentMessage = "Thank you for installing the latest version!"

if isLatestInstalled {
  message = currentMessage
} else {
  message = upgradeMessage
}

// does the same as if statement above
// message = conditional ? true : false
message = isLatestInstalled ? currentMessage : upgradeMessage


print(message)
//: [Previous](@previous) | [Next](@next)



import Foundation
