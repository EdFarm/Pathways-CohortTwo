//: ## `if` Statements
/*:
 - Simplest conditional statement
 - "if this is true, then... do that"
 */
// example structure of if statements
if true { // then..
  // do a thing
  // run some code
}

let dayOfTheWeek = "Wednesday"

let isTuesday = dayOfTheWeek == "Tuesday"
let isThursday = dayOfTheWeek == "Thursday"
let swiftClassDay = isTuesday || isThursday

if swiftClassDay {
  print("Let's learn Swift tonight!")
}

if !swiftClassDay {
  print("Relax, no class tonight")
}

//: [Previous](@previous) | [Next](@next)
