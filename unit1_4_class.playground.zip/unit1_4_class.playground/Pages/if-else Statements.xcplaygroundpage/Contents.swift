//: ## if-else Statements
/*:
- Related to the `if` statement
 - Allows for an additional block of code if the condition is false
 */
if true { // if condition is true
  // run this block of code...
} else {
  // run this other block of code...
}

let dayOfTheWeek = "Tuesday"

let isSwiftNight = dayOfTheWeek == "Tuesday" || dayOfTheWeek == "Thursday"

if isSwiftNight {
  print("Let's learn Swift tonight!")
} else {
  print("Relax, no class tonight")
}
//: [Previous](@previous) | [Next](@next)
