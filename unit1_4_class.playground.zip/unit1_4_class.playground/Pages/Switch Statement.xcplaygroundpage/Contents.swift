//: ## Switch Statement
//: ### Too many if-else statements?
/*:
- Helps to clean up long if-else chains
- All cases MUST be covered
- `default` covers cases not explicitly covered
- Some languages require a `break` statement to prevent code from falling through to the next case. Swift requires `fallthrough` to make the code explicitly fall through
*/
//switch value {
//case match:
//  // do some code here...
//default:
//  // else...
//}


let dayOfTheWeek = "Thursday"

switch dayOfTheWeek {
case "Monday": // dayOfTheWeek == "Monday"
  print("Looks like somebody's got a case of the Mondays...")
case "Tuesday", "Thursday":
  print("Let's learn Swift tonight!")
case "Wednesday":
  print("Midweek madness")
case "Friday":
  print("Ready for the weekend!")
default:
  print("Living that weekend life!")
}

let letter = "a"
//if letter == "a" || letter == "e" || letter == "i"
switch letter {
case "a", "e", "i", "o", "u":
  print("hey it's vowel!")
case "y":
  print("sometimes")
default:
  print("not a vowel")
}
//: [Previous](@previous) | [Next](@next)
