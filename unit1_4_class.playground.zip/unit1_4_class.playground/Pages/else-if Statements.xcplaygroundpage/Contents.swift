//: ## else-if Statements
/*:
- A third way to structure `if` statements
 - Allows for multiple additional blocks of code, each with a conditional statement to check
 */
if true { // if condition is true
  // do this...
} else if true {
  // do another thing...
} else if true {
  // do yet another thing... and so on...
} else {
  // do that...
}

let dayOfTheWeek = "Tuesday"
let hourOfTheDay = 21

if dayOfTheWeek == "Tuesday" {
  if hourOfTheDay == 19 {
    print("Let's learn Swift tonight!")
  } else {
    print("It's not time for Swift!")
  }
} else if dayOfTheWeek == "Thursday" {
  print("Almost the weekend but let's learn some Swift!")
} else if dayOfTheWeek == "Saturday" || dayOfTheWeek == "Sunday" {
  print("Have a great weekend!")
} else {
  // otherwise...
  print("Relax, no class tonight")
}
//: [Previous](@previous) | [Next](@next)
