//: ## Logical Operators
/*:
 - New list of operators, similar to Unit 1.3
 - Compare the left and right values to determine a `true` or `false` (boolean) value.
 */
//: ### Challenge Time!
//: What is the result of the following statements?
/*:
- Callout(Left and right value are equal): ==
*/
1 == 1
1 == 2
/*:
- Callout(Left and right value are not equal): !=
*/
1 != 2
3 != 3
/*:
- Callout(Left value is greater than the right value ): >
*/
1 > 3
3 > 3
8 > 4
/*:
- Callout(Left value is greater than OR equal to the right value ): >=
*/
1 >= 3
3 >= 3
8 >= 4
/*:
- Callout(Left value is less than the right value ): <
*/
1 < 3
3 < 3
8 < 4
/*:
- Callout(Left value is less than or equal to the right value ): <=
*/
1 <= 3
3 <= 3
8 <= 4
/*:
- Callout(Left value AND right value are both TRUE): &&
*/
true && true
false && false
true && false
false && true // false prevents running later code
(1 < 3) && (2 >= 2)
(1 != 2) && false
/*:
- Callout(Left value OR right value is TRUE): ||
*/
true || true
false || false
true || false
false || true
(8 > 4) || (4 < 2)
false || (100 > 500) || true || false || false
/*:
- Callout(Returns the opposite of the following statement): !
*/
!true
!false
!(!true)
!(8 < 4)
!(15 >= 15)
//: [Previous](@previous) | [Next](@next)


import Foundation
