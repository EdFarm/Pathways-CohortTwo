//: ## Challenge Time!
/*:
 - Callout(Callout): Let's convert this from an if-else to a switch!
 */
let temperature = 85

if temperature > 32 && temperature < 212 {
  print("It's water!")
} else if temperature <= 32 {
  print("It's ice!")
} else {
  print("It's steam!")
}

// we can simplify the logic a bit with a rearrangement
// let's also deal with those "magic" numbers...

//: [Previous](@previous) | [Next](@next)


import Foundation
