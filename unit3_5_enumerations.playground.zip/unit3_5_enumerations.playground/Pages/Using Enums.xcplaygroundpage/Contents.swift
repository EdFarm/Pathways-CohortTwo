//: ## Using Enums
/*:
 - Callout(What if...): We want to use the enum values to do something?
 */
struct WeatherReport {
    var status: WeatherStatus
    var temperature: Int
    var windSpeed: Int
    var windDirection: WindDirection
}

enum WeatherStatus {
    case sunny
    case cloudy
}

enum WindDirection {
    case north, northEast, east, southEast, south, southWest, west, northWest
}
//: ---
// we can use switch to check our cases!
func reportConditionsFor(_ weather: WeatherReport) {
    // check status first
    let statusReport: String
    switch weather.status {
    case .sunny:
        statusReport = "beautiful, with no clouds in the sky"
    case .cloudy:
        statusReport = "cloudy, with chance of rain"
//    default:
//        statusReport = "Who knows what's out there?!"
    }

    // then get wind conditions
    let windConditions: String
    if weather.windDirection == .north || weather.windDirection == .northEast || weather.windDirection == .northWest {
        windConditions = "cooler air coming from the north"
    } else {
        if weather.windSpeed <= 10 {
            windConditions = "light breeze"
        } else {
            windConditions = "strong gusts"
        }
    }

    print("Today the weather will be \(statusReport) with a temperature of \(weather.temperature). Wind conditions will include \(windConditions) at \(weather.windSpeed) mph.")
}

var currentWeather = WeatherReport(status: .cloudy, temperature: 75, windSpeed: 5, windDirection: .northWest)

reportConditionsFor(currentWeather)
//: ---

//: [Previous](@previous) | [Next](@next)

import Foundation
