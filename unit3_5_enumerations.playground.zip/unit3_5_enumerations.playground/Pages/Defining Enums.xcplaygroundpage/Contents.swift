//: ## Defining Enums
/*:
 - Callout(What if...): We want to store a value that is one of a limited set of options?
 */
struct WeatherReport {
    var status: String
    var temperature: Int
    var windSpeed: Int
    var windDirection: String
}

var currentWeather = WeatherReport(status: "Cloudy", temperature: 75, windSpeed: 5, windDirection: "Northwest")
//: [Previous](@previous) | [Next](@next)


import Foundation
