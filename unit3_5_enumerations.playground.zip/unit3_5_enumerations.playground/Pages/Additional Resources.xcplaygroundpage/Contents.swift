//: ## Additional Resources
/*:
 [Apple's Swift Enum Documentation](https://docs.swift.org/swift-book/LanguageGuide/Enumerations.html#)
 */
//: [Previous](@previous) | [Next](@next)

import Foundation
