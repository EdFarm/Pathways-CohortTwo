//: ## nil
/*:
 - callout(What if...?):
 What if we had an app that displayed musicians
 */
struct Musician {
  var firstName: String
  var lastName: String
}

var prince = Musician(firstName: "Prince", lastName: "") // does this work?

//var pink = Musician(firstName: "P!nk", lastName: nil)
// oh no... that doesn't work

/*:
 - callout(So...):
 How do we allow a nil value for lastName?
 
 */
//: [Previous](@previous) | [Next](@next)
