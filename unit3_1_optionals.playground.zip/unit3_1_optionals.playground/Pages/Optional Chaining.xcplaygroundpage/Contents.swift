//: ## Optional Chaining
/*:
 - callout(What if...):
 Our types need to have nested optional values?
 */
struct Ingredient {
    var name: String
    var amount: String
    var store: Store?
}

struct Store {
    var name: String
    var locationName: String?
    var address: Address?
}

struct Address {
  var street: String
  var unit: String?
}

let pastryAddress = Address(street: "123 Pastry Lane", unit: "45A")
let flourShoppe = Store(name: "The Flour Shoppe", locationName: "Pastry Lane", address: pastryAddress)

let apFlour = Ingredient(name: "all-purpose flour", amount: "2 cups", store: flourShoppe)
let blueberries = Ingredient(name: "blueberries", amount: "1 cup", store: nil)

// optional chaining
// PYRAMID OF DOOOOOOOOM!!
if let store = apFlour.store {
    if let storeAddress = store.address {
        if let storeAddressUnit = storeAddress.unit {
            print("You can find \(apFlour.name) at \(store.name), located at \(storeAddress.street), unit \(storeAddressUnit)")
        }
    }
}
/*:
 - callout(An Easier Way):
 Check this out...
 */
// removes the pyramid of doom, still handles binding
if let store = apFlour.store,
   let storeAddress = store.address,
   let storeAddressUnit = storeAddress.unit {
    print("You can find \(apFlour.name) at \(store.name), located at \(storeAddress.street), unit \(storeAddressUnit)")
}

// if you only need to get at a single value in the chain
if let storeAddressUnit = apFlour.store?.address?.unit {
    print("The unit number of \(apFlour.name) is \(storeAddressUnit)")
}

// flow of optional chaining
// ingredient.store?.address?.number___> value
//             \\   \\
//              \\___\\________> nil
//: [Previous](@previous) | [Next](@next)
import Foundation
