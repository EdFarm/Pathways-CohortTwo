//: ## Force Unwrapping
/*:
 - callout(What if...):
 We wanted to stop worrying about if something is nil and __use it!__
 */
let aRecipe: Recipe? = Recipe(name: "Cheese Biscuits", ingredients: ["1 1/2 cups flour", "1 cup sugar", "1 cup shredded cheddar cheese", "3/4 cup milk (2% works best)", "1 egg, beaten well", "4 tablespoons butter, softened", "1 1/2 teaspoons baking powder", "1/4 teaspoon vanilla"], directions: ["1. Mix all ingredients together. Pour into greased muffin pan and bake at 400 for 15 - 20 minutes.", "2. This recipe make about 12 muffins."], cookingTime: 25)

let maybeDelicious: Recipe? = nil

if aRecipe != nil {
    let realRecipe = aRecipe! // force unwrap here
    print(realRecipe.name)
}

// force unwrapping nil = OH NO!
let anotherRecipe = maybeDelicious!
//: [Previous](@previous) | [Next](@next)


import Foundation
