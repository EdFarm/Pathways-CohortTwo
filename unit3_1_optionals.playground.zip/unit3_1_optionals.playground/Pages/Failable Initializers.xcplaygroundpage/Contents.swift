//: ## Failable Initializers
/*:
 - callout(What if...):
 An initializer could result in an optional value?
 */
class Recipe {
    public var name: String
    public var ingredients: [String]
    public var directions: [String]
    public var cookingTime: Int

    public init?(name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        if ingredients.isEmpty || directions.isEmpty {
            // without ingredients or directions, I don't think this is a recipe!
            return nil
        } else {
            self.name = name
            self.ingredients = ingredients
            self.directions = directions
            self.cookingTime = cookingTime
        }
    }
}

if let maybeRecipe = Recipe(name: "Dump Cake", ingredients: ["1 pkg yellow cake mix", "1 cup butter", "8 oz. coconut", "20 oz. can of pineapple"], directions: ["Mix pineapple and coconut and spread evenly on the bottom of a greased 9 x 13 inch pan.", "DUMP cake mix evenly over fruit mixture.", "Cover surface with small pieces of butter.", "DON'T MIX!", "Bake at 350F for 45 minutes or until lightly browned.", "Cool and cut into squares.", "Serves 20."], cookingTime: 45) {
    print(maybeRecipe.name)
}

if let notARecipe = Recipe(name: "Dump Cake", ingredients: [], directions: ["Mix pineapple and coconut and spread evenly on the bottom of a greased 9 x 13 inch pan.", "DUMP cake mix evenly over fruit mixture.", "Cover surface with small pieces of butter.", "DON'T MIX!", "Bake at 350F for 45 minutes or until lightly browned.", "Cool and cut into squares.", "Serves 20."], cookingTime: 45) {
    print(notARecipe.name)
} else {
    print("There weren't enough ingredients or directions to make that a real recipe!")
}

//: [Previous](@previous) | [Next](@next)
import Foundation
