//: # Optionals
//: ---
/*:
 ## Lesson Plan
 - nil
 - Optional Type Annotation
 - Unwrapping Optionals
 - Optional Binding
 - Using Optionals
 - Failable Initializers
 - Optional Chaining
 */
//: [Previous](@previous) | [Next](@next)
