//: ## Optional Binding
/*:
 - callout(What if...):
 There was a better way to unwrap the values?
 */
let aRecipe: Recipe? = Recipe(name: "Cheese Biscuits", ingredients: ["1 1/2 cups flour", "1 cup sugar", "1 cup shredded cheddar cheese", "3/4 cup milk (2% works best)", "1 egg, beaten well", "4 tablespoons butter, softened", "1 1/2 teaspoons baking powder", "1/4 teaspoon vanilla"], directions: ["1. Mix all ingredients together. Pour into greased muffin pan and bake at 400 for 15 - 20 minutes.", "2. This recipe make about 12 muffins."], cookingTime: 25)

let maybeDelicious: Recipe? = nil

// if let syntax
if let realRecipe = aRecipe {
    print(realRecipe.name)
}

// if let - else syntax
if let anotherRecipe = maybeDelicious { // is maybeBus nil? assign to anotherBus
    print(anotherRecipe.name)
} else {
  print("that's not a recipe, it's NIL!")
}

//: [Previous](@previous) | [Next](@next)


import Foundation
