//: ## Optional Type Annotations
/*:
 - callout(What if...):
 Let's say we're building a recipe app, and we need to search for a recipe in our system that _might_ exist, or _might_ not...
 */
class Recipe {
    var name: String
    var ingredients: [String]
    var directions: [String]
    var cookingTime: Int

    init(name: String, ingredients: [String], directions: [String], cookingTime: Int) {
        self.name = name
        self.ingredients = ingredients
        self.directions = directions
        self.cookingTime = cookingTime
    }
}

// inferred type, not optional
let aRecipe = Recipe(name: "Cheese Biscuits", ingredients: ["1 1/2 cups flour", "1 cup sugar", "1 cup shredded cheddar cheese", "3/4 cup milk (2% works best)", "1 egg, beaten well", "4 tablespoons butter, softened", "1 1/2 teaspoons baking powder", "1/4 teaspoon vanilla"], directions: ["1. Mix all ingredients together. Pour into greased muffin pan and bake at 400 for 15 - 20 minutes.", "2. This recipe make about 12 muffins."], cookingTime: 25)

// annotated with optional
let possibleRecipe: Recipe? = Recipe(name: "Chocolate Mousse", ingredients: ["1 ⅔ cups heavy cream", "2 tsp. vanilla extract", "½ tsp. kosher salt", "4 egg whites", "½ cup sugar", "6 oz. bittersweet chocolate, melted and cooled", "Chocolate shavings, to garnish"], directions: ["In a large bowl, beat cream, vanilla, and salt with a whisk until stiff peaks form; chill.", "In another large bowl, beat egg whites with a whisk until soft peaks form. While whisking, slowly add sugar, and continue beating until stiff peaks form.", "Add melted chocolate to egg whites, and fold until almost incorporated; add whipped cream and fold until completely incorporated.", "Divide among serving cups; chill.", "Sprinkle with chocolate shavings before serving."], cookingTime: 20)

// what about this? Does this work?
//let anotherPossibleRecipe = nil

// try this instead
let anotherPossibleRecipe: Recipe? = nil
//: [Previous](@previous) | [Next](@next)


import Foundation
