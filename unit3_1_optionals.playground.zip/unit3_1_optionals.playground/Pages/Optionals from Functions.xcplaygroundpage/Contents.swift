//: ## Optionals from Functions
/*:
 - callout(What if...):
 We need to use a function that returns an optional?
 */
let fibArray = [1, 2, 3, 5, 8, 13, 21]

var checkValue = 8
// check out the documentation for `firstIndex` here
if let realNum = fibArray.firstIndex(of: checkValue) {
  print(realNum)
}

checkValue = 7
let myNum = fibArray.firstIndex(of: checkValue)
if let maybeNum = myNum {
  print(maybeNum)
} else {
  print("can't find index for \(checkValue)")
}

//: [Previous](@previous) | [Next](@next)
import Foundation
