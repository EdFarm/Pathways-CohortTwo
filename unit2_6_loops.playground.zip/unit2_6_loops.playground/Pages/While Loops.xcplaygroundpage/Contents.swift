//: ## While Loops
/*:
 - While loops run while a conditional statement is `true`
 - Remember to iterate the counter to avoid endless loops!
 */
var counter = 0
while counter <= 10 && counter >= -15 {
  print(counter)
  counter -= 1
}
//: [Previous](@previous) | [Next](@next)


import Foundation
