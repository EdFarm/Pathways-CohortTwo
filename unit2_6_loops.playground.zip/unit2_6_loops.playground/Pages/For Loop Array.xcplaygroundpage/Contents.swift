//: ## For Loop with Arrays
/*:
 - For loops can also be used with collections
 - The loop is run once per item in the collection
 */
// Let's use a useful method to split up a string!
let sentence = "Hello there Pathways how are you tonight?"
let words = sentence.split(separator: " ")
//let words = ["Hello", "there", "Pathways", "how", "are", "you", "tonight?"]

print("There are \(words.count) words in our sentence!")

for word in words {
    print(word)
}
//: [Previous](@previous) | [Next](@next)


import Foundation
