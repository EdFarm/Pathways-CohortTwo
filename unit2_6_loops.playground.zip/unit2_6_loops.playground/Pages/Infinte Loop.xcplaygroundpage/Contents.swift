//: ## Infinte Loop!?
/*:
 - Oh NO...
 */
//let counter = 0
//while true {
//  print(counter)
//  print("Can somebody slow this thing down?! I want to get off this ride!")
//    counter += 1
//}
//: [Previous](@previous) | [Next](@next)


import Foundation
