//: ## For Loop with Structs
/*:
 - What if we wanted to loop through an array of another type??
 */
struct Note {
    var title: String
    var note: String
    var completed: Bool = false
}

let classPlan = Note(title: "Loop", note: "Plan the loops class material for Pathways!", completed: true)
let reminder = Note(title: "IMPORTANT!", note: "Don't forget to do that thing. You know... the one you always forget. You don't remember which one it is, do you?")
let catapult = Note(title: "Candy Catapult", note: "Look into building a candy catapult to keep the kids distanced while still delivering a quality sugar high.")

let notes = [catapult, reminder, classPlan]

var completedCount = 0
for note in notes {
    if note.completed {
        completedCount += 1
    } else {
        print("You should get started working on \(note.title) - it'll be great!")
    }
}

print("If you feel like you need a break, you can do that too - you've completed \(completedCount) tasks!")
//: [Previous](@previous) | [Next](@next)


import Foundation
