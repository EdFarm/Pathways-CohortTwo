//: ## What's a Protocol?
/*:
 - A blueprint of methods, properties and requirements 
 - Types (Structs and Classes) `adopt` a protocol to add functionality
 - To adopt a protocol, a type must implement all methods of that protocol
 - Types that adopt a protocol are said to `conform` to that protocol
 - Swift includes many protocols by default
 - Names for protocols often end in `-ible` or `-able`
 - Swift has been referred to as a "Protocol-Oriented Language"
 */
//: [Previous](@previous) | [Next](@next)
