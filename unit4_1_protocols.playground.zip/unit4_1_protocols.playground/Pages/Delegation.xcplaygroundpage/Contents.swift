//: ## Delegation
/*:
 - Allows one object to call upon another to do work for it ("Delegating" work to something else)
 - Allows for flexible separation of responsibility
 - Is very often used in UIKit
 - We'll use delegate methods next week with UITableViews!
 */

//: ## DEMO TIME!

//: [Previous](@previous) | [Next](@next)

import Foundation
