//: ## Codable
/*:
 - callout(What if...): We want to store our data in our app or convert data coming from a web server?
 - Automatic if all properties conform to Codable already (Most Swift standard library types do!)
 - Built into Swift by default
 */
import Foundation
struct Person {
    var firstName: String
    var lastName: String
    var age: Int
}
//: [Previous](@previous) | [Next](@next)
