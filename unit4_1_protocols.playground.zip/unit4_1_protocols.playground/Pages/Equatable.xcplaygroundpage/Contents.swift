//: ## Equatable
/*:
 - callout(What if...): determine if two instances of our custom type are equal?
 - Allows us to build custom logic to determine if two instances are equal to each other
 - Built into Swift by default
 */
struct Person {
  var firstName: String
  var lastName: String
  var age: Int
}
//: [Previous](@previous) | [Next](@next)
import Foundation
