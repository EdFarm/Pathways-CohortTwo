//: ## Creating Your Own Protocols
/*:
 - 
 */
protocol Flyable {
  // protocol property
  var airspeed: Double { get set }
  
  // protocol method
  func isFlying() -> Bool
}

class Animal {
  // ... more code for the class here...
}
class Mammal: Animal {}
class Bird: Animal {}
class Penguin: Bird {}

class Parrot: Bird {} // hey! that's flyable!

class Vehicle {}
class Car: Vehicle {}

class Plane: Vehicle {} // hey! that's flyable too!
//: [Previous](@previous) | [Next](@next)


import Foundation
