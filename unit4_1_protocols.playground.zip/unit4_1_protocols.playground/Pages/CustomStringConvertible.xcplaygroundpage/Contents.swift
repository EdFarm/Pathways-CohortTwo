//: ## CustomStringConvertible
/*:
 - callout(What if...): we want to print out information about our custom types?
 - Allows us to print what we want about our types in a more legible way
 - Built into Swift by default
 */
struct Person {
    var firstName: String
    var lastName: String
    var age: Int
}
//: [Previous](@previous) | [Next](@next)
import Foundation
