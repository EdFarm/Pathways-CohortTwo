//: ## Comparable
/*:
 - callout(What if...): we want to be able to sort our custom types based on their properties?
 - Built into Swift by default
 */
struct Person {
    var firstName: String
    var lastName: String
    var age: Int
}
//: [Previous](@previous) | [Next](@next)
import Foundation
