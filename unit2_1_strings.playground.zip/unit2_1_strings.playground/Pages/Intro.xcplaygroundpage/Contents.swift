//: # Strings
//: ## Unit 2.1
/*:
 - How to declare and use String values
 - Comparing Strings
 - String concatenation and interpolation
 - Substrings
 */
//: [Next](@next)
