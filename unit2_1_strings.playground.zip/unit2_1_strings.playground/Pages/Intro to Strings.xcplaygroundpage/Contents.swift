//: ## Intro to Strings
/*:
 - Text is EVERYWHERE in our world!
 - Strings are how we represent text in code using Swift
 */

/*:
 - Callout(What if...): we were building an app to read news?
 */

let title: String = "Good News Today!"
let authorFirstName = "Cam"
let authorLastName = "Davis"

// what about longer pieces of text?
let article = """
Text is everywhere. You’ll find it on billboards, on social media, on bills, and on cereal boxes. So it should come as no surprise that text is just as vital in programming as it is everywhere else in our world.

In this lesson, you’ll learn how to create and store text using the String type. You’ll learn a variety of String methods that allow you to compare two strings, access particular characters within a string, and insert and remove values.
"""

print(article)

//: [Previous](@previous) | [Next](@next)


import Foundation


/*
 Excerpt From: Apple Education. “Develop in Swift Fundamentals.” Apple Inc. - Education, 2020. Apple Books. https://books.apple.com/us/book/develop-in-swift-fundamentals/id1511184145
 */
