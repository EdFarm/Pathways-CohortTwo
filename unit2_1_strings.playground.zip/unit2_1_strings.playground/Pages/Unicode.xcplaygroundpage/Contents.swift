//: ## Unicode
//: ### One Standard, Many Languages
/*:
 - Unicode is the standard for handling text in code that allows for a variety of writing systems.
 - It standardizes a single representation for each character in any language, including emoji!
 - More than 128,000 characters included
 - Swift helps by hiding some of the complexity of Unicode
 - [Swift Language String Documenation](https://docs.swift.org/swift-book/LanguageGuide/StringsAndCharacters.html)
 */
//: [Previous](@previous) | [Next](@next)
import Foundation

