//: ## "Escaping" in Strings
/*:
 - Example: Why doesn't this work?

    `let complexTitle = "New movie "Monsters, Heroes, and Explosions" released online and in theaters"`
 */

//: What about multi-line strings?
let article = """
Today, a new movie, "Monsters, Heroes, and Explosions" was released for audiences worldwide. Action movie fans can catch the film both online and in theaters.
"""
/*:
 - Callout(The Ecape Character): `\` (backslash)
 */
/*: The escape character allows us to "escape" certain characters in a string

 Let's see if we can fix the title string 👆
 */
let complexTitle = "New movie \"Monsters, Heroes, and Explosions\" released online and in theaters"
print(complexTitle)


/*: There are a few more key cases where escape characters are useful

 `'`

 `\`

 Tabs

New lines
 */
let backslashString = "hello \\ there"
print(backslashString)

let tabString = "This should have a gap right \t here."
print(tabString)

let twoLineString = "1. Here is one line. \n2. Here is another."
print(twoLineString)
//: [Previous](@previous) | [Next](@next)


import Foundation
