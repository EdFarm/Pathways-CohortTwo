//: ## Looking Inside Strings
/*:
 - Sometimes we need to check on what's inside a string
 - There are several properties and methods we have available to help with that
 */
import Foundation

let emptyString = ""
let title = "Taylor Swift Learns to Program in Swift"

print("Empty String Stats:")
print(emptyString.isEmpty)
print(emptyString.count)

print("Title String Stats:")
print(title.isEmpty)
print(title.count)

if (title.hasPrefix("Taylor Swift")) {
    print("found another article!")
    // do whatever else!
}

if (title.hasSuffix("Swift")) {
    print("another Swift article found!")
    // do something after matching suffix
}

if (title.contains("Learns")) {
    print("found a matching string!")
    // do something if it matches...
}
// calling a method on "title"
//: [Previous](@previous) | [Next](@next)
