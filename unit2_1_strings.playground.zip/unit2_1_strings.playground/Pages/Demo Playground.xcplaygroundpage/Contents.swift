import Foundation

var str = "Hello, playground"

if (str.contains("ll")) {
    print("IT WORKS!")
}
