//: ## Switching Characters
/*:
 - Characters can also be used to trigger a switch
 */
let aCharacter: Character = "a"
switch aCharacter {
case "a", "e", "i", "o", "u":
    print("\(aCharacter) is a vowel!")
case "y":
    print("\(aCharacter) is sometimes a vowel!")
default:
    print("\(aCharacter) is not a vowel.")
}

//: [Previous](@previous) | [Next](@next)


import Foundation
