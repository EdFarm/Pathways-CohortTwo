//
//  ViewController.swift
//  tabBarDemo
//
//  Created by Taylor Smith on 10/22/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func openShare(_ sender: Any) {
        let alertController = UIAlertController(title: "Hello", message: "Welcome to sharing!", preferredStyle: .actionSheet)
        self.present(alertController, animated: true, completion: nil)
    }
}

