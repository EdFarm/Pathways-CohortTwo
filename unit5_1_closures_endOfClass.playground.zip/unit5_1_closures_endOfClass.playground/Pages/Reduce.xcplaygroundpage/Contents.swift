//: ## Closures and `reduce()`
/*:
 - `reduce()` allows us to use all values in a collection to reach a single value
 - result begins with an initial value argument
 */
var total: Double = 0
for item in cart {
    total += item.subtotal
}
print(total)
//: let's do the same work with `reduce()`...
let reduceTotal = cart.reduce(0, { (currentTotal, cartItem) -> Double in
    print(currentTotal)
    return currentTotal + cartItem.subtotal
})

print(reduceTotal)
//: [Previous](@previous) | [Next](@next)

import Foundation
