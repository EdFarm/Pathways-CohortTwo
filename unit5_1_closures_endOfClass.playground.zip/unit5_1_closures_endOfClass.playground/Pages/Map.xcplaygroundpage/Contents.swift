//: ## Closures and `map()`
/*:
 - `map()` allows us to run a closure on each value inside a collection
 - the result is another collection containing the type returned by the closure
 - useful for removing/simplifying `for` loops
 */
print(cart)
var capitalizedItems: [String] = []
for item in cart {
    let capitalizedItem = item.name.capitalized
    capitalizedItems.append(capitalizedItem)
}

print(capitalizedItems)

//: let's do the same work with `map()`...
let mapCapitalizedNames = cart.map({ (cartItem) -> String in
    return cartItem.name.capitalized
})

print(mapCapitalizedNames)

let modifiedItems = cart.map({ (cartItem) -> CartItem in
    var modifiedItem = cartItem
    modifiedItem.name = modifiedItem.name.uppercased()
    return modifiedItem
})

print(modifiedItems)

let intArray = [1, 3, 5, 6, 9, 10, 15]
let doubledArray = intArray.map({ (number) -> Int in
    return number * 2
})

print(doubledArray)
//: [Previous](@previous) | [Next](@next)


import Foundation
