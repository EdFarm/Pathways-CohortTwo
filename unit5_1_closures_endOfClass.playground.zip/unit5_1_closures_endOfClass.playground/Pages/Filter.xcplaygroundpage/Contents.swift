//: ## Closures and `filter()`
/*:
 - `filter()` allows us to remove/retain items in a collection based on the `bool` return value of a closure
 - the result is another collection containing the same type as the original collection
 */
print(cart)
var loopedItems: [CartItem] = []

for item in cart {
//    if item.name.first == "b" {
//        loopedItems.append(item)
//    }

    if item.price >= 5.00 {
        loopedItems.append(item)
    }
}

print("loopedItems - \(loopedItems)")

//: let's do the same work with `filter()`...
let filteredItems = cart.filter({ (cartItem) -> Bool in
    return cartItem.price >= 5.00
})

print("filteredItems - \(filteredItems)")
//: [Previous](@previous) | [Next](@next)
import Foundation
