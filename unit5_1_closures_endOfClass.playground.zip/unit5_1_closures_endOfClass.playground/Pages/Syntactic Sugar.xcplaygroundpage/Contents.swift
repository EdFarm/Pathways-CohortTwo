//: ## Syntactic Sugar
/*:
 - More concise code that has the same effect as before
 - Brevity comes with complexity when reading
 */
// removing parentheses
//let mapCapitalizedNames = cart.map { (cartItem) -> String in
//    return cartItem.name.capitalized
//}



let mapCapitalizedNames = cart.map { cartItem -> String in
    return cartItem.name.capitalized
}

// return type inference
let sortedCart = cart.sorted { cartItem1, cartItem2 in
    return cartItem1.name < cartItem2.name
}

// trailing syntax
let reduceTotal = cart.reduce(0.00) { currentTotal, cartItem in
    return currentTotal + cartItem.subtotal
}

// placeholder names
let placeholderCart = cart.sorted { $0.name < $1.name }
    .map { $0.name.capitalized }
print(placeholderCart)

// capture
let hello = "Hello"
let captureDemo = cart.reduce(0.00) { currentTotal, cartItem in
    print(hello)
    return currentTotal + cartItem.subtotal
}

//: [Previous](@previous) | [Next](@next)


import Foundation
