//: ## Setup
/*:
 - We'll be using this struct and data through the rest of the examples
 
 - Callout(What if...): we were building a grocery ecommerce app?
 */
struct CartItem: CustomStringConvertible {
    // properties
    var name: String
    var price: Double
    var quantity: Int

    // computed property
    var subtotal: Double {
        return price * Double(quantity)
    }

    var description: String {
        return "\(name) - $\(price) x \(quantity) = $\(subtotal)"
    }
}

let bananas = CartItem(name: "bananas", price: 0.49, quantity: 5)
let salmon = CartItem(name: "salmon", price: 13.99, quantity: 1)
let milk = CartItem(name: "milk", price: 5.49, quantity: 2)
let rice = CartItem(name: "rice", price: 1.79, quantity: 2)
let brussels = CartItem(name: "brussels sprouts", price: 3.29, quantity: 2)
let pizza = CartItem(name: "frozen pizza", price: 7.89, quantity: 1)

// array of all items in my cart
let cart = [bananas, salmon, milk, rice, brussels, pizza]

//: [Previous](@previous) | [Next](@next)


import Foundation
