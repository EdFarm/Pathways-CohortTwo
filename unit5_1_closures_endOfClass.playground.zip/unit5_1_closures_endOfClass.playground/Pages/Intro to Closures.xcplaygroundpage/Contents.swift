//: ## Intro to Closures
/*:
 - Closures are self-contained blocks of code that can be used elsewhere as needed
 - Often referred to as "anonymous functions"
 - Can be stored in variables or passed directly as arguments
 - Used often by UIKit as arguments in methods
 - "Callbacks" or "Completion Handlers" are common names in the UIKit context
 */
func doAthing(completion: () -> Void) {
    print("doing something slowly...")
    // do something long running here...
    completion()
}

doAthing(completion: {() in
    print("hello completion handler")
}
)

// function
func hello() {
    print("Hello Pathways!")
}

// closure
let hi = {
    print("Hi Pathways!")
}

hello()
hi()

// function
func totalFor(items: [CartItem]) -> Double {
    var total: Double = 0
    for item in items {
        total += item.subtotal
    }
    return total
}

totalFor(items: cart)

// closure
let totalClosure = { (items: [CartItem]) -> Double in
    var total: Double = 0
    for item in items {
        total += item.subtotal
    }
    return total
}

totalClosure(cart)
//: [Previous](@previous) | [Next](@next)


import Foundation
