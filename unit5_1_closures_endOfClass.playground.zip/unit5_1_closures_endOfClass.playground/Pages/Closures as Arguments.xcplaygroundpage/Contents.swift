//: ## Closures as Arguments
/*:
 - Closures can be passed into functions/methods as an argument
 - Allows for additional, customizable behavior to be added to a function

 - callout(What if...): We needed to sort the items in our cart?
 */
print(cart)
let sortedCart = cart.sorted(by: { (cartItem1, cartItem2) -> Bool in
    return cartItem1.name < cartItem2.name
})

print(sortedCart)
//: [Previous](@previous) | [Next](@next)
import Foundation
